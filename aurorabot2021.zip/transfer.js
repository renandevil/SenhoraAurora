const dbddb = require('dbd.db')
const dbdjs = require('dbdjs.db')

const dbd = dbddb('database')
const col = dbd.collection({ name: 'Variables' })
const db = new dbdjs.Database({
  path: "./new-database/",
  tables: [{ name: "main" }]
})

db.once('ready', async () => {
  const all = await col.find({})

  for (const obj of all) {
    if (obj.variable) {
      if (obj.varID == '0') await db.set("main", `${obj.variable}`, obj.value)
      else await db.set("main", `${obj.variable}_${obj.varID}`, obj.value)
    } else if (obj.guild) {
      await db.set("main", `invite-tracker_${obj.guild}_${obj.id}`, {
        inviter: {
          id: obj.inviter.id,
          code: obj.inviter.code
        },
        real: obj.real,
        fake: obj.fake
      })
    }
  }
})

db.connect() 
