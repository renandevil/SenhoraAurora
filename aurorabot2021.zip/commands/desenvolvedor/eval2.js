module.exports.command = {
name: "eval2", aliases: ["e2"],
code: `
código
\`\`\`
$message
\`\`\`
tipo
\`\`\`
$djsEval[typeof(eval(\`$message\`));yes]
\`\`\`
resultado
\`\`\`
$djsEval[$message;yes]
\`\`\`
$onlyForIDs[$botOwnerID;]
`
};