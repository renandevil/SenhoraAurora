module.exports.command = {
name: "eval", aliases: ["e"],
code: `$eval[$message;yes]
$onlyForIDs[$botOwnerID;]`
}