module.exports.command = {
name: "reboot",
aliases: ["restart"],
code: `
$reboot[index.js]
$onlyForID[$botOwnerID;]
`
}