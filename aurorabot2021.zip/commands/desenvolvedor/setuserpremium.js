module.exports.command = {
  name: "setuserpremium",
  code: `
$setGlobalUserVar[userpremium;ativado;$findUser[$message;no]]
$description[✅ Premium setado para $username[$findUser[$message;no]] com sucesso!]
$onlyForIDs[$botOwnerID;]
`
}