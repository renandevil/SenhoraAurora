module.exports.status = {
text: "$getServerVar[prefix]help | $getServerVar[prefix]invite | $getVar[versao]",
type: "PLAYING",
time: 15
}