module.exports.status = {
text: "$getServerVar[prefix]gender | tocando rádios! | $getVar[versao]",
type: "PLAYING",
time: 15
}