module.exports.status = {
text: "$getServerVar[prefix]help | guilds: $serverCount | $getVar[versao]",
type: "PLAYING",
time: 30
}