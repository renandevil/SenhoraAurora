module.exports.status = {
text: "$getServerVar[prefix]help | vote em mim no top.gg | $getVar[versao]",
type: "PLAYING",
time: 20
}