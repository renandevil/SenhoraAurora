module.exports.status = {
text: "$getServerVar[prefix]help | dev: Senhora ?#6151 | $getVar[versao]",
type: "PLAYING",
time: 10
}