module.exports.status = {
text: "$getServerVar[prefix]help | online: $uptime | $getVar[versao]",
type: "PLAYING",
time: 30
}