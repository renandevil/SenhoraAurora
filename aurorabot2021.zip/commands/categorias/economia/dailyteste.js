module.exports.command = {
  name: "testediario",
  code:` 
$if[$getGlobalUserVar[userpremium]$checkCondition[$getGlobalUserVar[req]=<5]==ativadotrue]
  
  $thumbnail[https://cdn.discordapp.com/attachments/815368954079346749/820846494453858324/daily2.png]
  $description[daily consecutivo
Seu Combo atual é \`$getGlobalUserVar[combo]\`]

$setGlobalUserVar[combo;$math[$getGlobalUserVar[combo]+1]]
$setGlobalUserVar[req;$math[$getGlobalUserVar[req]+1]]
$endif

$if[$getGlobalUserVar[userpremium]$checkCondition[$getGlobalUserVar[req]==5]==ativadotrue]

{thumbnail:https://cdn.discordapp.com/attachments/815368954079346749/820846588091432960/daily5.png}
{description:você pegou seu daily \`$getGlobalUserVar[combo]\` vezes, como recompensa vc ganhou **nada, to testando**

Seu Combo atual é \`$getGlobalUserVar[combo]\`}

$setGlobalUserVar[combo;$math[$getGlobalUserVar[combo]+1]]
$setGlobalUserVar[req;1]
$endif
`
}