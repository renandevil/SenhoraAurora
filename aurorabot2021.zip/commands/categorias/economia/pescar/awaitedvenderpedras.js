module.exports.command = {
  name: "vender", aliases: "sell",
  code: `$if[$checkcontains[$message;pedras]==true]
  
  $wait[2s]
  
 $setGlobalUserVar[creams;$sum[$getGlobalUserVar[creams];$math[$getGlobalUserVar[pedra]*3]]]
 
 $onlyIf[$getGlobalUserVar[pedra]>=1;]
 
  $endif
  `
  }