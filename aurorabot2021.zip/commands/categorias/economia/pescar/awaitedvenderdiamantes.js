module.exports.command = {
  name: "vender", aliases: "sell",
  code: `$if[$checkcontains[$message;diamantes]==true]
  
  $wait[2s]
  
 $setGlobalUserVar[creams;$sum[$getGlobalUserVar[creams];$math[$getGlobalUserVar[diamante]*30]]]
 $onlyIf[$getGlobalUserVar[diamante]>=1;]
 
  $endif
  `
  }