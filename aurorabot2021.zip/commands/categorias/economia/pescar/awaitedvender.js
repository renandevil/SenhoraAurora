module.exports.command = {
  name: "vender", aliases: "sell",
  code: `$if[$checkcontains[$message;peixes]==true]
  
  $wait[2s]
  
 $setGlobalUserVar[creams;$sum[$getGlobalUserVar[creams];$math[$getGlobalUserVar[peixes]*15]]]

 
 $onlyIf[$getGlobalUserVar[peixes]>=1;]
 
  $endif
  `
  }