module.exports.command = {
  name: "vender", aliases: "sell",
  code: `$if[$checkcontains[$message;peixes]==true]
  
  $wait[3s]
  
 $setGlobalUserVar[peixes;0]
 
 $onlyIf[$getGlobalUserVar[peixes]>=1;]
 
  $endif
  `
  }