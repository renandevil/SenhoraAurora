module.exports.command = {
  name: "vender", aliases: "sell",
  code: `$if[$checkcontains[$message;pedras]==true]
  
  $wait[3s]
  
 $setGlobalUserVar[pedra;0]
 
 $onlyIf[$getGlobalUserVar[pedra]>=1;]
 
  $endif
  `
  }