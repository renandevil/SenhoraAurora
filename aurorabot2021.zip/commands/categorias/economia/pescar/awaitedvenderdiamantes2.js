module.exports.command = {
  name: "vender", aliases: "sell",
  code: `$if[$checkcontains[$message;diamantes]==true]
  
  $wait[3s]
  
 $setGlobalUserVar[diamante;0]
 
 $onlyIf[$getGlobalUserVar[diamante]>=1;]
 
  $endif
  `
  }