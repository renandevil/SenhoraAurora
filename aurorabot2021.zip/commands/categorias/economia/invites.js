module.exports.command = {
 name: "invites",
 code: `
 $title[Convites de $username[$findUser[$message]]#$discriminator[$findUser[$message]]]
$thumbnail[$userAvatar[$findUser[$message]]]
$description[
**Convites Fakes:** $userInfo[fake;$findUser[$message]]
**Convites Reais:** $userInfo[real;$findUser[$message]]
**Total de Convites:** $sum[$userInfo[real;$findUser[$message]];$userInfo[fake;$findUser[$message]]]
]
$deletecommand
$color[$getVar[color]]

$onlyForIDs[$botOwnerID;]`
}