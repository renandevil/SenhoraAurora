module.exports.command = {
 name: "mochila", aliases: ["backpack", "bg", "bag"],
 code: `
 $deletecommand
 <@$authorID>
 $thumbnail[$userAvatar[$mentioned[1;yes]]]
 $title[<a:yay:829829170832998421> $username[$mentioned[1;yes]]'s - Backpack]
 $description[\`(Categoria>>Nome>>Quantidade)\`\n<a:setinharosa:829829148762570772>Utilize \`$getServerVar[prefix]vender <Item>\` para aumentar o espaço da sua mochila!]

$addField[**Equipamentos:**;
🎣 Vara de Pesca - \`($getGlobalUserVar[vara1;$mentioned[1;yes]]/1)\`
<:picareta:845391921178214441> Picareta - \`($getGlobalUserVar[picareta;$mentioned[1;yes]]/1)\`]

$addField[**Itens:**;
🐟 Peixes - \`($getGlobalUserVar[peixes;$mentioned[1;yes]]/$getGlobalUserVar[mochila1;$mentioned[1;yes]])\`
<:pedra:845390723860004889> Pedras - \`($getGlobalUserVar[pedra;$mentioned[1;yes]]/150)\`
<a:diamante:845391077715607573> Diamantes - \`($getGlobalUserVar[diamante;$mentioned[1;yes]]/50)\`
🥠 Biscoitinho da Sorte - \`($getGlobalUserVar[fortunecookie;$mentioned[1;yes]]/$getGlobalUserVar[mochila1;$mentioned[1;yes]])\`]
 $color[#FEB1D5]
 $footer[$username;$authorAvatar]
 
 $cooldown[10s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:10s} {deletecommand}]
 
 $channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]`
}