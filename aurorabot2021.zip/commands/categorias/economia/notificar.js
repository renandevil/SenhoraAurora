module.exports.command = {
name: "notificar",
code: `$if[$getGlobalUserVar[lembrete]==desativado]
$deletecommand
$author[✅ Lembrete automático Ativado]
$description[Agora irei lhe lembrar na DM quando seu cooldown de pescar e de minerar resetar!]
$color[#FEB1D5]
$footer[$username;$authorAvatar]

$setGlobalUserVar[lembrete;ativado]

$cooldown[5s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:5s} {deletecommand}]

$endif

$if[$getGlobalUserVar[lembrete]==ativado]
$deletecommand
$author[✅ Lembrete automático Desativado]
$description[Não irei mais lhe lembrar dos cooldowns na DM.]
$color[#FEB1D5]
$footer[$username;$authorAvatar]

$setGlobalUserVar[lembrete;desativado]

$cooldown[5s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:5s} {deletecommand}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]

$endif


`
}