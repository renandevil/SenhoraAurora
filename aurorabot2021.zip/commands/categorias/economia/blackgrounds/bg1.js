module.exports.awaitedCommand = {
name: "bg1",
code: `$reactionCollector[$message[1];$authorID;40s;💰,🎒,➡️;compra1,equip1,bg2]
$editMessage[$message[1];{title:backgrounds (1/8)}{field:Nome:**Clean Pink**}{field:ID:\`1\`}{field:Preço:Padrão}{footer:Reaja 💰 para comprar o background}{color:#FEB1D5}{image:https://cdn.discordapp.com/attachments/780281654211117097/824131187366559765/rosafundopreto.png}]
$clearReactions[$channelID;$message[1];all]
$suppressErrors[]`
  }