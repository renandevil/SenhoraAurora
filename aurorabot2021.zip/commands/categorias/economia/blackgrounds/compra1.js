module.exports.awaitedCommand = {
name: "compra1",
code: `$editMessage[$message[1];{title:Clean Pink}{field:✅ Compra Realizada com Sucesso!:Background **Clean Pink**}{field:ID:\`1\`}{field:Preço:Padrão}{color:#FEB1D5}{image:https://cdn.discordapp.com/attachments/780281654211117097/824131187366559765/rosafundopreto.png}]
$clearReactions[$channelID;$message[1];all]
$suppressErrors[]

$setGlobalUserVar[bg1;https://cdn.discordapp.com/attachments/780281654211117097/824131187366559765/rosafundopreto.png]
$setGlobalUserVar[background;https://cdn.discordapp.com/attachments/780281654211117097/824131187366559765/rosafundopreto.png]
$setGlobalUserVar[creams;$sub[$getGlobalUserVar[creams];1000]]

$onlyIf[$getGlobalUserVar[bg1;$authorID]==false;{description: **Você já tem este background comprado**}{color: FEB1D5} {delete:10s}]

$onlyIf[$getGlobalUserVar[creams]=<1000; {description: **Você não tem 1000 Creams**} {color: FEB1D5} {delete:10s}]
`
  }