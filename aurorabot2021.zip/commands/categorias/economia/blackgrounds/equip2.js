module.exports.awaitedCommand = {
name: "equip2",
code: `$editMessage[$message[1];{title:Clean Green}{field:✅ Background equipado com Sucesso!:Background **Clean Green**}{field:ID:\`2\`}{field:Preço:1000 Creams}{color:#FEB1D5}{image:https://cdn.discordapp.com/attachments/780281654211117097/824526689228029962/PicsArt_03-25-02.10.39.jpg}]
$clearReactions[$channelID;$message[1];all]
$suppressErrors[]

$setGlobalUserVar[background;https://cdn.discordapp.com/attachments/780281654211117097/824526689228029962/PicsArt_03-25-02.10.39.jpg]

$onlyIf[$getGlobalUserVar[bg2;authorID]==https://cdn.discordapp.com/attachments/780281654211117097/824526689228029962/PicsArt_03-25-02.10.39.jpg;{description: **Você não tem este background comprado**}{color: FEB1D5} {delete:10s}]`
  }