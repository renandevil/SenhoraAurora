module.exports.awaitedCommand = {
name: "bg2",
code: `$reactionCollector[$message[1];$authorID;40s;⬅️,💰,🎒,➡️;bg1,compra2,equip2,bg3]
$editMessage[$message[1];{title:backgrounds (2/8)}{field:Nome:**Clean Green**}{field:ID:\`2\`}{field:Preço:1000 Creams}{footer:Reaja 💰 para comprar o background}{color:#FEB1D5}{image:https://cdn.discordapp.com/attachments/780281654211117097/824526689228029962/PicsArt_03-25-02.10.39.jpg}]
$clearReactions[$channelID;$message[1];all]
$suppressErrors[]`
  }