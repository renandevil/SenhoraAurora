module.exports.awaitedCommand = {
name: "equip1",
code: `$editMessage[$message[1];{title:Clean Pink}{field:✅ Background equipado com Sucesso!:Background **Clean Pink**}{field:ID:\`1\`}{field:Preço:1000 Creams}{color:#FEB1D5}{image:https://cdn.discordapp.com/attachments/780281654211117097/824131187366559765/rosafundopreto.png}]
$clearReactions[$channelID;$message[1];all]
$suppressErrors[]

$setGlobalUserVar[background;https://cdn.discordapp.com/attachments/780281654211117097/824131187366559765/rosafundopreto.png]

$onlyIf[$getGlobalUserVar[bg1;$authorID]==https://cdn.discordapp.com/attachments/780281654211117097/824131187366559765/rosafundopreto.png;{description: **Você não tem este background comprado**}{color: FEB1D5} {delete:10s}]`
  }