module.exports.command = {
 name: "loja", aliases: ["shop"],
 code: `
 $deletecommand
 $thumbnail[$authorAvatar]
 $author[Aurora™ - Loja]
 $description[\`(ID>>Nome>>Preço)\`
<a:setinharosa:829829148762570772>Utilize \`$getServerVar[prefix]buy <ID>\` para comprar algo da loja!]
$addField[🥠 **Itens:**;
 
\`a\` - **Biscoitinho da Sorte** - 500 Creams]
 $addField[⚒️ **Equipamentos:**;
\`vara\` - **Vara de Pesca** - 800 Creams
\`picareta\` - **Picareta** - 300 Creams
]
$addField[📷 **Backgrounds:**;
\`1a\` - **Fortnite** - 10000 Creams
\`1b\` - **Rocket League** - 10000 Creams
\`1c\` - **Your Name** - 10000 Creams
\`1d\` - **Your Name2** - 10000 Creams
]

 $color[#FEB1D5]
 $footer[$username;$authorAvatar]
 
 $channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]`
}