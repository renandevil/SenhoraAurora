module.exports.command = {
name: "curtidasleaderboard", aliases: ["likes-lb", "likes-rank", "top-likes", "curtidas-top", "likes-top", "likes-lb", "rank-likes"],
code: `$description[$globalUserLeaderboard[likes;asc;**{top}°** - ❤️ {username} - Likes: **{value}**;15]
<a:BFL_trofeu_gif:753023901872947270> Você está **top #$getLeaderboardInfo[likes;$authorID;globaluser;top]** do Ranking Global de Curtidas!]
$title[❤️ Rank Global de Perfis Mais Curtidos]
$footer[$username;$authorAvatar]
$color[#FEB1D5]
$deletecommand

$cooldown[15s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:15s} {deletecommand}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]

$setVar[comandos;$sum[$getVar[comandos];1]]`
}