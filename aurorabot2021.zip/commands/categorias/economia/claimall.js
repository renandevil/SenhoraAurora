module.exports.command = {
  name: "claimall", aliases: "cooldown",
  code: `<@$authorID>
  $title[Claimall]
$description[-> Cooldowns prontos e em andamento:

$replaceText[$replaceText[$checkCondition[$getCooldownTime[24h;globalUser;daily;$authorID]==0];true;<:A_ligado:791038425326420018> | **Daily:** \`a!daily\`];false;<:A_desligado:791063885133905951> | Daily: \`$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$getCooldownTime[24h;globalUser;daily;$authorID];months;meses];month;mes];days;dias];day;dia];hours;horas];hour;hora];minutes;minutos];minute;minuto];seconds;segundos];second;segundo];and;e];years;anos];year;ano];weeks;semanas];week;semana]\`]
$replaceText[$replaceText[$checkCondition[$getCooldownTime[30m;globalUser;pescar;$authorID]==0];true;<:A_ligado:791038425326420018> | **Pescar:** \`a!pescar\`];false;<:A_desligado:791063885133905951> | Pescar: \`$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$getCooldownTime[30m;globalUser;pescar;$authorID];months;meses];month;mes];days;dias];day;dia];hours;horas];hour;hora];minutes;minutos];minute;minuto];seconds;segundos];second;segundo];and;e];years;anos];year;ano];weeks;semanas];week;semana]\`]
$replaceText[$replaceText[$checkCondition[$getCooldownTime[20m;globalUser;minerar;$authorID]==0];true;<:A_ligado:791038425326420018> | **Minerar:** \`a!minerar\`];false;<:A_desligado:791063885133905951> | Minerar: \`$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$getCooldownTime[20m;globalUser;minerar;$authorID];months;meses];month;mes];days;dias];day;dia];hours;horas];hour;hora];minutes;minutos];minute;minuto];seconds;segundos];second;segundo];and;e];years;anos];year;ano];weeks;semanas];week;semana]\`]
$replaceText[$replaceText[$checkCondition[$getCooldownTime[12h;globalUser;verify;$authorID]==0];true;<:A_ligado:791038425326420018> | **Upvote:** \`a!verificar\`];false;<:A_desligado:791063885133905951> | Upvote: \`$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$getCooldownTime[12h;globalUser;verify;$authorID];months;meses];month;mes];days;dias];day;dia];hours;horas];hour;hora];minutes;minutos];minute;minuto];seconds;segundos];second;segundo];and;e];years;anos];year;ano];weeks;semanas];week;semana]\`]

]
$footer[$username;$authorAvatar]
$color[$getVar[color]]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]
  
  `
}