module.exports.command = {
  name: "vender", aliases: "sell",
  code: `$if[$checkcontains[$message;peixes]==true]
 $deletecommand
 $author[✅ Vendido com sucesso!]
 $description[Você vendeu $getGlobalUserVar[peixes] Peixes por $math[$getGlobalUserVar[peixes]*15] Creams!
 Pesque mais peixes usando \`$getServerVar[prefix]pescar\`]
 $color[FEB1D5]
 $footer[$username;$authorAvatar]
 
 $deleteIn[15s]
 
 $onlyIf[$getGlobalUserVar[peixes]>=1;{description: Você precisa ter pelo menos 1 peixe, utilize \`$getServerVar[prefix]pescar\` e pesque mais peixes!} {deletecommand} {delete:10s} {color: FEB1D5}]
 
  $endif
  
  $if[$checkcontains[$message;pedras]==true]
 $deletecommand
 $author[✅ Vendido com sucesso!]
 $description[Você vendeu $getGlobalUserVar[pedra] Pedras por $math[$getGlobalUserVar[pedra]*3] Creams!
 Minere mais pedras usando \`$getServerVar[prefix]minerar\`]
 $color[FEB1D5]
 $footer[$username;$authorAvatar]
 
 $deleteIn[15s]
 
 $onlyIf[$getGlobalUserVar[pedra]>=1;{description: Você precisa ter pelo menos 1 pedra, utilize \`$getServerVar[prefix]minerar\` e pegue mais pedras!} {deletecommand} {delete:10s} {color: FEB1D5}]
 
  $endif
  
  $if[$checkcontains[$message;diamantes]==true]
 $deletecommand
 $author[✅ Vendido com sucesso!]
 $description[Você vendeu $getGlobalUserVar[diamante] diamante por $math[$getGlobalUserVar[diamante]*30] Creams!
 Minere mais diamantes usando \`$getServerVar[prefix]minerar\`]
 $color[FEB1D5]
 $footer[$username;$authorAvatar]
 
 $deleteIn[15s]
 
 $onlyIf[$getGlobalUserVar[diamante]>=1;{description: Você precisa ter pelo menos 1 diamante, utilize \`$getServerVar[prefix]minerar\` e pegue mais diamantes!} {deletecommand} {delete:10s} {color: FEB1D5}]
 
  $endif
  
  $argsCheck[>1;Especifique o item que queira vender, 
**Exemplo:** \`$getServerVar[prefix]vender peixes\` {deletecommand} {delete:15s}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]

  `
  }