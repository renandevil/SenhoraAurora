module.exports.command = {
  name: "pescar",
  code: `$deletecommand
  
  $color[#FEB1D5]
 $footer[$username;$authorAvatar]
  $author[Pescar]
  $description[🎣 **Você pescou e conseguiu alguns itens!**
  
-> $random[50;300] Creams;
-> $random[2;5] Peixes;
-> $random[2;7] Botas.

Venda seus itens e libere espaço na mochila!
\`$getServerVar[prefix]vender peixes\`
]
  
  $setGlobalUserVar[creams;$sum[$getGlobalUserVar[creams];$random[50;300]]]
  $setGlobalUserVar[peixes;$sum[$getGlobalUserVar[peixes];$random[2;5]]]
  
  $globalCooldown[30m;{description:⏰ $username Você já pescou e está cansado, espere %time% para pescar novamente!} {color:#FEB1D5} {deletecommand} {delete:10s}]
  
$onlyIf[$getGlobalUserVar[peixes]=<50;{description: Sua mochila está cheia de peixes, utilize \`$getServerVar[prefix]vender peixes\` para esvaziar!} {deletecommand} {delete:10s} {color: FEB1D5}]
  
  $onlyIf[$getGlobalUserVar[vara1]==1;{description: **Você não tem uma Vara de Pesca, compre na $getServerVar[prefix]loja**}{color: FEB1D5} {deletecommand} {delete:10s}]
  
  $channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]`
}