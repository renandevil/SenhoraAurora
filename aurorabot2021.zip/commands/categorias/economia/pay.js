module.exports.command = {
 name: "pay",
 aliases: ['pagar', 'give'], 
 code: `$if[$message[1]==teste]
 
 $setGlobalUserVar[pay;$mentioned[1]]
 $setGlobalUserVar[paycreams;$message[2]]
 $setGlobalUserVar[payauthor;$authorID]
 
 $awaitMessages[$authorID;2m;sim,cancelar;confirmepay,cancelarpay;]
 
 ❓ <@$authorID> Você deseja enviar ao usuário **$username[$mentioned[1]]** um valor de $message[2] Creams? (Você irá perder $message[2] de sua conta e passará para ele(a), e está ação não terá mais volta, não nos responsabilizamos se você for "roubado" ou enganado, para confirmar, digite \`sim\`, caso queire cancelar esta transação, digite \`cancelar\`
 
 $endif
 
 $description[<:presente:829923760923869184> <@$authorID> acabou de dar $message[2] Creams para <@$mentioned[1]>!

✅ **Creams atualmente de cada um:**
- $username[$mentioned[1]] - $getGlobalUserVar[creams;$mentioned[1]] Creams;
- $username[$authorID] - $getGlobalUserVar[creams;$authorID] Creams.
]
$color[FEB1D5]

$setGlobalUserVar[creams;$sum[$getGlobalUserVar[creams;$mentioned[1]];$message[2]];$mentioned[1]]
 
 $setGlobalUserVar[creams;$sub[$getGlobalUserVar[creams;$authorID];$message[2]];$authorID]
 
$onlyIf[$isBot[$mentioned[1]]==false;{description: Você não pode dar creams para um bot}{color: FEB1D5} {deletecommand} {delete:5s}]

$onlyIf[$replaceText[$replaceText[$checkCondition[$toLowercase[$message[2]]==all];true;$getGlobalUserVar[creams]];false;$message[2]]>0;{description: Você precisa dar no mínimo 1 cream para alguém}{color: FEB1D5} {deletecommand} {delete:5s}]

$onlyIf[$getGlobalUserVar[creams]>=$replaceText[$replaceText[$checkCondition[$toLowercase[$message[2]]==all];true;$getGlobalUserVar[creams]];false;$message[2]];{description: Você não tem creams o suficiente}{color: FEB1D5}{deletecommand} {delete:5s}]

$onlyIf[$isNumber[$replaceText[$replaceText[$checkCondition[$toLowercase[$message[2]]==all];true;$getGlobalUserVar[creams]];false;$message[2]]]==true;{description: Você utilizou o comando errado, utilize \`$getServerVar[prefix]pay <usuário> < Valor | All >\` para dar para alguém}{color: FEB1D5} {deletecommand} {delete:10s}]

$onlyIf[$mentioned[1]!=$authorID;{description: Você não pode pagar a si mesmo}{color: FEB1D5} {deletecommand} {delete:5s}]

$onlyIf[$mentioned[1]!=;{description: Você precisa mencionar alguém para pagar uma quantia}{color: FEB1D5} {deletecommand} {delete:5s}]

$cooldown[10s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:10s} {deletecommand}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]

$setVar[comandos;$sum[$getVar[comandos];1]]`
}