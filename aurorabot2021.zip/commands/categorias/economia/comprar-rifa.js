module.exports.command = {
name: 'comprar-rifa',
code: `


$setVar[rifa_total;$sum[$getVar[rifa_total];$multi[350;$message]]]
$setVar[rifa_users;$replaceText[$replaceText[$checkCondition[$getVar[rifa_users]==];true;$authorID];false;$authorID, ]]

Você comprou $message tickets da rifa por \`\`\`$multi[500;$message]\`\`\` creams!

$onlyIf[$getGlobalUserVar[creams]=>350;Você precisa de 350 creams.]
`
}