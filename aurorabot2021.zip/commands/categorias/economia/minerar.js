module.exports.command = {
  name: "minerar", aliases: "mine",
  code: `$deletecommand
  
  $color[#FEB1D5]
 $footer[$username;$authorAvatar]
  $author[Minerar]
  $description[<:picareta:845391921178214441> **Você minerou e conseguiu alguns itens!**
  
-> $random[30;150] Creams;
-> $random[2;25] Pedras;
-> $random[2;5] Diamantes.

Venda seus itens e libere espaço na mochila!
\`$getServerVar[prefix]vender pedras\`
\`$getServerVar[prefix]vender diamantes\`
]
  
  $setGlobalUserVar[creams;$sum[$getGlobalUserVar[creams];$random[30;150]]]
  $setGlobalUserVar[pedra;$sum[$getGlobalUserVar[pedra];$random[2;25]]]
  $setGlobalUserVar[diamante;$sum[$getGlobalUserVar[diamante];$random[2;5]]]
  
  $globalCooldown[20m;{description:⏰ $username Você já minerou e está cansado, espere %time% para pescar novamente!} {color:#FEB1D5} {deletecommand} {delete:10s}]
  
$onlyIf[$getGlobalUserVar[pedra]=<150;{description: Sua mochila está cheia de pedras, utilize \`$getServerVar[prefix]vender pedras\` para esvaziar!} {deletecommand} {delete:10s} {color: FEB1D5}]

$onlyIf[$getGlobalUserVar[diamante]=<50;{description: Sua mochila está cheia de diamantes, utilize \`$getServerVar[prefix]vender diamantes\` para esvaziar!} {deletecommand} {delete:10s} {color: FEB1D5}]
  
  $onlyIf[$getGlobalUserVar[picareta]==1;{description: **Você não tem uma Picareta, compre na \`$getServerVar[prefix]loja\`**}{color: FEB1D5} {deletecommand} {delete:10s}]
  
  $channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]`
}