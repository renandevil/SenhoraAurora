module.exports.command = {
  name: "testebackgrounds", aliases: ["testebackground", "testewallpaper"],
  code: `$reactionCollector[$splitText[1];$authorID;40s;💰,🎒,➡️;compra1,equip1,bg2]
	$textSplit[$sendMessage[{title:backgrounds (1/8)}{field:Nome:**Clean Pink**}{field:ID:\`1\`}{field:Preço:Padrão}{footer:Reaja 💰 para comprar o background}{color:#FEB1D5}{image:https://cdn.discordapp.com/attachments/780281654211117097/824131187366559765/rosafundopreto.png};yes]]
	$onlyBotPerms[embedlinks;Eu preciso da permissão de \`EMBED_LINKS\` para poder utilizar este comando!]
  $deletecommand
 
$cooldown[15s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:15s} {deletecommand}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]


$onlyForIDs[$botOwnerID;]`
}