module.exports.command = {
 name: "daily", aliases: "diário",
 code: `
 $deleteCommand
 $author[Daily Claim]
 
 $thumbnail[https://cdn.discordapp.com/attachments/829829137455644712/830900320086261820/1614625124817.png]
 
$description[<:creams:829853319405109318> Você pegou o daily de hoje e ganhou $random[400;1300] Creams!
<:presente:829923760923869184> Agora você tem $sum[$getGlobalUserVar[creams];$random[200;1300]] Creams!
<a:BFL_trofeu_gif:753023901872947270> Você está **top #$getLeaderboardInfo[creams;$authorID;globaluser;top]** do Ranking Global de Creams!

-> Utilize \`$getServerVar[prefix]claimall\` para ver todos seus cooldowns ativos.

🌟 Sabia que você pode deixar seu anúncio aqui apenas por uma certa quantia? além de ser super barato, você pode divulgar seu vídeo, canal, live, entre outras coisas! O sistema de anúncios foi implantado para me ajudar a ficar online e ajudar os outros também! saiba mais no meu [servidor de suporte](https://discord.gg/vXvMU3Wcwq) - ainda em construção.]

$addField[Anúncios;$getVar[ads]]

$color[#FEB1D5]
$footer[$username;$authorAvatar]

$setGlobalUserVar[creams;$sum[$getGlobalUserVar[creams];$random[400;1300]]]

$globalCooldown[24h;⏰ $userTag Você já pegou seu daily de hoje, espere %time% e pegue novamente! {deletecommand} {delete:10s}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]

`
}