module.exports.command = {
  name: "curtir", aliases: "like",
  code: `
$globalCooldown[2h;⏰ <@$authorID> Você já curtiu um perfil, espere %time% e curta outro novamente. {deletecommand} {delete:5s}]
  
  $deletecommand
  <@$authorID>
  $footer[$username;$authorAvatar]
  
  $title[✅ Curtida entregue com Sucesso!]
  $description[Você deu 1 curtida para $username[$mentioned[1]] e agora ele(a) possui $sum[$getGlobalUserVar[likes;$mentioned[1]];1] Likes!]
  $color[FEB1D5]
  
  $setGlobalUserVar[likes;$sum[$getGlobalUserVar[likes;$findMember[$message[1]]];1];$findMember[$message[1]]]
  
 $onlyIf[$mentioned[1]!=$authorID;{description: Você não pode curtir o seu próprio perfil}{color: FEB1D5} {deletecommand} {delete:5s}]

$onlyIf[$mentioned[1]!=;{description: Você precisa mencionar alguém para curtir o perfil}{color: FEB1D5} {deletecommand} {delete:5s}]

 $channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]

$setVar[comandos;$sum[$getVar[comandos];1]]`
}