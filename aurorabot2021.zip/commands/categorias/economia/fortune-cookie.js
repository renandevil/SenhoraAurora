module.exports.command = {
  name: "fortune-cookie", aliases: ["boicoito da sorte", "fortunecookie"],
  code: `$deletecommand
  
  $color[#FEB1D5]
 $footer[$username;$authorAvatar]
  $author[🥠 Biscoitinho da Sorte]
  $description[**Você abriu um biscoitinho da sorte e ganhou $random[1;700] Creams!** <a:yay:829829170832998421>
  Agora você tem $getGlobalUserVar[fortunecookie] Biscoitos]
  
  $setGlobalUserVar[creams;$sum[$getGlobalUserVar[creams];$random[1;700]]]
  
  $setGlobalUserVar[fortunecookie;$sub[$getGlobalUserVar[fortunecookie];1]]
  
  $onlyIf[$getGlobalUserVar[fortunecookie]>=1;{description: **Você não tem um Biscoitinho da Sorte, compre na $getServerVar[prefix]loja**}{color: FEB1D5} {deletecommand} {delete:10s}]
  
  $channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]
`
}