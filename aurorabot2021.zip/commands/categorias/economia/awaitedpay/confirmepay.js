module.exports.awaitedCommand = {
name: "confirmepay",
code: `$awaitMessages[$getGlobalUserVar[pay];2m;aceito,recusar;confirmarpay,recusarpay;]
$sendMessage[✅ <@$getGlobalUserVar[pay]> Você aceita receber um pagamento do usuário <@$authorID> no valor de $message[2] Creams? para confirmar, digite \`aceito\`, caso queire recusar esta transação, digite \`recusar\`;no]
$suppressErrors[]

`
}