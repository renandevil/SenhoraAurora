module.exports.awaitedCommand = {
name: "cancelarpay",
code: `✅ **Pagamento cancelado.**`
}