module.exports.awaitedCommand = {
name: "recusarpay",
code: `✅ **Pagamento recusado.**`
}