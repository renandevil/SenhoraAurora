module.exports.awaitedCommand = {
name: "confirmarpay",
code: `$description[<:presente:829923760923869184> <@$getGlobalUserVar[payauthor]> acabou de dar $getGlobalUserVar[paycreams] Creams para <@$getGlobalUserVar[pay]>!

✅ **Creams atualmente de cada um:**
$username[$getGlobalUserVar[pay]] - $getGlobalUserVar[creams;$getGlobalUserVar[pay]] Creams;
$username[$getGlobalUserVar[payauthor]] - $getGlobalUserVar[creams;$getGlobalUserVar[payauthor]] Creams.
]
$color[FEB1D5]

 $setGlobalUserVar[creams;$sum[$getGlobalUserVar[creams;$getGlobalUserVar[pay]];$getGlobalUserVar[paycreams]];$getGlobalUserVar[pay]]
 
 $setGlobalUserVar[creams;$sub[$getGlobalUserVar[creams;$getGlobalUserVar[payauthor]];$getGlobalUserVar[paycreams]];$getGlobalUserVar[payauthor]]
`
}