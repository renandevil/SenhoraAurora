module.exports.command = {
name: "balance", aliases: ["atm","creams", "cream", "bal"],
code:`$deleteCommand
<@$authorID>

 $author[$username[$mentioned[1;yes]]'s Balance]
 $thumbnail[$replaceText[$replaceText[$checkCondition[$mentioned[1;yes]==$getGlobalUserVar[userpremium;ativado]];true;https://cdn.discordapp.com/attachments/815368954079346749/820169638524354560/creamblue2.png];false;https://cdn.discordapp.com/attachments/815368954079346749/820169615065874472/cream2.png]]

$description[$replaceText[$replaceText[$checkCondition[$mentioned[1;yes]==$getGlobalUserVar[userpremium;ativado]];true;<:creamblue2:817083830774661210> **Usuário Premium |**];false;<:creams:829853319405109318>] **$username[$mentioned[1;yes]]** tem $getGlobalUserVar[creams;$mentioned[1;yes]] Creams!
<a:BFL_trofeu_gif:753023901872947270> **$username[$mentioned[1;yes]]** está **top #$getLeaderboardInfo[creams;$mentioned[1;yes];globaluser;top]** do Ranking Global de Creams!
]
$footer[$username;$authorAvatar]
$color[#FEB1D5]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]
`
}