module.exports.loopCommand = {
channel: "829818699392745502",
code: `
O ganhador foi: <@$randomText[$joinSplitText[;]]>
$textSplit[$getVar[rifa_users];, ]
`,
every: 1000 * 60 * 60,
executeOnStartup: true
}