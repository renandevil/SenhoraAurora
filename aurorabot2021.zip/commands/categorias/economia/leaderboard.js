module.exports.command = {
name: "leaderboard", aliases: ["lb", "top", "rank"],
code: `
<@$authorID>
$description[$globalUserLeaderboard[creams;asc;**{top}°** - <:creams:829853319405109318> {username} - Creams: **{value}**;15]
<a:BFL_trofeu_gif:753023901872947270> Você está **top #$getLeaderboardInfo[creams;$authorID;globaluser;top]** do Ranking Global de Creams!]
$title[<:creams:829853319405109318> Rank Global de Creams]
$footer[$username;$authorAvatar]
$color[#FEB1D5]
$deletecommand

$cooldown[15s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:15s} {deletecommand}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]

$setVar[comandos;$sum[$getVar[comandos];1]]`
}