module.exports.command = {
name: "pescar",
code: `$cooldown[30m]
$if[$getGlobalUserVar[lembrete]==ativado]
$DM
$wait[30m]
$author[🔔 Lembrete de Pescar!]
$description[<a:yay:829829170832998421> Pesque novamente utilizando $getServerVar[prefix]pescar e consiga Creams!]
$cooldown[30m]
$color[#FEB1D5]
$footer[$username;$authorAvatar]
$thumbnail[https://cdn.discordapp.com/attachments/815368954079346749/825084100125655040/varadepesca_2.png]

$endif
`
}