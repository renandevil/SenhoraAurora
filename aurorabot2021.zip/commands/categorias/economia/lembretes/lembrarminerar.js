module.exports.command = {
name: "minerar", aliases: "mine",
code: `$cooldown[20m]
$if[$getGlobalUserVar[lembrete]==ativado]
$DM
$wait[20m]
$author[🔔 Lembrete de Minerar!]
$description[<a:yay:829829170832998421> Minere novamente utilizando $getServerVar[prefix]minerar e consiga Creams!]
$cooldown[20m]
$color[#FEB1D5]
$footer[$username;$authorAvatar]
$thumbnail[https://cdn.discordapp.com/attachments/829829137455644712/845397824353992754/picareta.png]

$endif
`
}