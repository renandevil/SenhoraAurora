module.exports.command = {
name: "daily", aliases: "diário",
code: `$cooldown[24h]
$if[$getGlobalUserVar[lembrete]==ativado]
$DM
$wait[24h]
$author[🔔 Lembrete do Daily!]
$description[<a:yay:829829170832998421> Pegue o daily novamente utilizando $getServerVar[prefix]daily e consiga Creams Diários!]
$color[#FEB1D5]
$footer[$username;$authorAvatar]
$cooldown[24h]
$thumbnail[https://cdn.discordapp.com/attachments/815368954079346749/820169615065874472/cream2.png]

$endif
`
}