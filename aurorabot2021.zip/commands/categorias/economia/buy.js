  module.exports.command = {
  name: "buy", aliases: "comprar",
  code: `$if[$checkcontains[$message;vara]==true]

  $deletecommand
✅ <@$authorID> Comprado com sucesso!
-> Você comprou 1 Vara de Pesca por 800 creams!
 
 Utilize \`$getServerVar[prefix]pescar\` para começar a pescar
 
 $setGlobalUserVar[creams;$sub[$getGlobalUserVar[creams];800]]
$setGlobalUserVar[vara1;1]
  
  $onlyIf[$getGlobalUserVar[creams]>=800; {description: **Você não tem 800 Creams**} {color: FEB1D5} {deletecommand} {delete:10s}]
  
  $onlyIf[$getGlobalUserVar[vara1]==0;{description: **Você já tem uma Vara de Pesca!**}{color: FEB1D5} {deletecommand} {delete:10s}]
$endif

$if[$checkcontains[$message;a]==true]

  $deletecommand
✅ <@$authorID> Comprado com sucesso!
-> Você comprou 🥠 \`$message[2]\` boicoitinhos da sorte por \`$multi[200;$message[2]]\` creams!
 
 Utilize \`$getServerVar[prefix]fortune-cookie\` para abrir seus biscoitinhos e veje se está com sorte hoje, você pode ganhar de \`1\` a \`700\` Creams!
 
 $setGlobalUserVar[creams;$sub[$getGlobalUserVar[creams];$multi[200;$message[2]]]]
 $setGlobalUserVar[fortunecookie;$sum[$getGlobalUserVar[fortunecookie];$message[2]]]
 
  $onlyIf[$getGlobalUserVar[creams]>=$multi[200;$message[2]]; {description: **Você não tem $multi[200;$message[2]] Creams**} {color: FEB1D5} {deletecommand} {delete:10s}]
  
  $onlyIf[$message[2]>0;{description: Especifique quantos 🥠 Bicoitinhos da Sorte você deseja comprar, tem que ser maior que 0} {color: FEB1D5} {deletecommand} {delete:10s}]
  
  $onlyIf[$message[2]<50;{description: Especifique quantos 🥠 Bicoitinhos da Sorte você deseja comprar, tem que ser menor que 50} {color: FEB1D5} {deletecommand} {delete:10s}]
  
  $argsCheck[>2; {description: **Específique quantos Biscoitinhos da Sorte deseja comprar, no mínimo 1**} {color: FEB1D5} {deletecommand} {delete:10s}]
$endif

$if[$checkcontains[$message;picareta]==true]

  $deletecommand
✅ <@$authorID> Comprado com sucesso!]
-> Você comprou 1 Picareta por 300 creams!
 
 Utilize \`$getServerVar[prefix]minerar\` para começar a minerar
 
 $setGlobalUserVar[creams;$sub[$getGlobalUserVar[creams];300]]
$setGlobalUserVar[picareta;1]
  
  $onlyIf[$getGlobalUserVar[creams]>=300; {description: **Você não tem 300 Creams**} {color: FEB1D5} {deletecommand} {delete:10s}]
  
  $onlyIf[$getGlobalUserVar[picareta]==0;{description: **Você já tem uma Picareta!**}{color: FEB1D5} {deletecommand} {delete:10s}]
$endif


$if[$checkcontains[$message;1a]==true]

  $deletecommand
**✅ <@$authorID> Comprado com sucesso!**
  -> Você comprou o background **Fortnite** por 10000 creams!
 
 Utilize \`$getServerVar[prefix]equip\` para equipar!
 
 $setGlobalUserVar[creams;$sub[$getGlobalUserVar[creams];10000]]
$setGlobalUserVar[bg2;true]
  
  $onlyIf[$getGlobalUserVar[creams]>=10000; {description: **Você não tem 10000 Creams**} {color: FEB1D5} {deletecommand} {delete:10s}]
  
  $onlyIf[$getGlobalUserVar[bg2]==false;{description: **Você já tem este background!**}{color: FEB1D5} {deletecommand} {delete:10s}]
  
$endif

$if[$checkcontains[$message;1b]==true]

  $deletecommand
**✅ <@$authorID> Comprado com sucesso!**
  -> Você comprou o background **Rocket League** por 10000 creams!
 
 Utilize \`$getServerVar[prefix]equip\` para equipar!
 
 $setGlobalUserVar[creams;$sub[$getGlobalUserVar[creams];10000]]
$setGlobalUserVar[bg33;true]
  
  $onlyIf[$getGlobalUserVar[creams]>=10000; {description: **Você não tem 10000 Creams**} {color: FEB1D5} {deletecommand} {delete:10s}]
  
  $onlyIf[$getGlobalUserVar[bg33]==false;{description: **Você já tem este background!**}{color: FEB1D5} {deletecommand} {delete:10s}]
$endif

$if[$checkcontains[$message;1c]==true]

  $deletecommand
**✅ <@$authorID> Comprado com sucesso!**
-> Você comprou o background **Your Name** por 10000 creams!
 
 Utilize \`$getServerVar[prefix]equip\` para equipar!
 
 $setGlobalUserVar[creams;$sub[$getGlobalUserVar[creams];10000]]
$setGlobalUserVar[bg4;true]
  
  $onlyIf[$getGlobalUserVar[creams]>=10000; {description: **Você não tem 10000 Creams**} {color: FEB1D5} {deletecommand} {delete:10s}]
  
  $onlyIf[$getGlobalUserVar[bg4]==false;{description: **Você já tem este background!**}{color: FEB1D5} {deletecommand} {delete:10s}]
$endif

$if[$checkcontains[$message;1d]==true]

  $deletecommand
 **✅ <@$authorID> Comprado com sucesso!**
 -> Você comprou o background **Your Name2** por 10000 creams!
 
 Utilize \`$getServerVar[prefix]equip\` para equipar!
 
 $setGlobalUserVar[creams;$sub[$getGlobalUserVar[creams];10000]]
$setGlobalUserVar[bg5;true]
  
  $onlyIf[$getGlobalUserVar[creams]>=10000; {description: **Você não tem 10000 Creams**} {color: FEB1D5} {deletecommand} {delete:10s}]
  
  $onlyIf[$getGlobalUserVar[bg5]==false;{description: **Você já tem este background!**}{color: FEB1D5} {deletecommand} {delete:10s}]
$endif

$argsCheck[>1;Especifique o ID do Item que queira comprar.
**Exemplo:**
\`$getServerVar[prefix]buy 1\` -> Compra uma picareta.
\`$getServerVar[prefix]buy ab\` -> Compra um puffin. {deletecommand} {delete:15s}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]`
}