module.exports.command = {
name: "serverinfo", aliases: "infoserver",
code: `$deletecommand
 $color[FEB1D5]
 $addfield[Total de Membros ($membersCount);ㅤ]
$addfield[Criado há;$guild[$guildID;created] ( $guild[$guildID;timestamp] )]
$addfield[💬 Canais ($channelCount[text;voice]);
📝 Canais de Texto: \`$channelCount[text]\`
🔊 Canais de Voz: \`$channelCount[voice]\`]
$addfield[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$serverRegion;brazil;🇧🇷];europe;🇪🇺];hong kong;🇨🇳];eua;🇺🇸];india;🇮🇳];japan;🇯🇵] Região; $replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$serverRegion;brazil;Brazil];europe;Europa];hong kong;Hong Kong];eua;Eua];india;India];japan;Japão]]
$addfield[Dono do Servidor;$userTag[$ownerID] ($ownerID)]
$addfield[ID;$guildID]
$title[$serverName - Info]
$thumbnail[$serverIcon]
$footer[$username;$authorAvatar]

$cooldown[10s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:5s} {deletecommand}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]

$setVar[comandos;$sum[$getVar[comandos];1]]`
}