module.exports.command = {
    name: "roleinfo", aliases: ["roleinformation", "inforole", "cargoinfo", "cargo"],
    code: `
    <@$authorID>
    $color[$role[$findRole[$message];hex]]
    $footer[$username;$authorAvatar]
    $author[Role Info]
    $addField[Hoisted; $replaceText[$replaceText[$checkCondition[$isHoisted[$findRole[$message]]==true];true;Sim];false;Não];yes]
    $addField[Mencionável; $replaceText[$replaceText[$checkCondition[$isMentionable[$findRole[$message]]==true];true;Sim];false;Não];yes]
    $addField[Hex; $role[$findRole[$message];hex];yes]
    $addField[ID; $findRole[$message];yes]
    $addField[Posição; $role[$findRole[$message];position];yes]
    $addField[Criado em; $role[$findRole[$message];created];yes]
  
  $deletecommand
  $onlyIf[$findRole[$message]!=; Não encontrei nenhum cargo com este nome, talvez ele não exista :c {deletecommand} {delete:10s}]
    $onlyIf[$message!=;{description: Especifique o cargo que queira saber as informações}{deletecommand} {delete:5s}]
    $suppressErrors[Algu deu errado... {deletecommand} {delete:5s}]
    $cooldown[5s; Você está no cooldown bobinho, espere %time% e tente novamente}{deletecommand}{delete:5s}]
    $onlyIf[$checkContains[$channelType;text;news]==true;]
    `
}