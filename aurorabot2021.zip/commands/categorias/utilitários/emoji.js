module.exports.command = {
 name: "emoji", aliases: ["emj", "emojo"],
 code: `$deletecommand

$color[#FEB1D5]
$title[Emoji]
$description[[Clique aqui](https://cdn.discordapp.com/emojis/$advancedtextsplit[$message[1];:;3;>;1].$replaceText[$replaceText[$stringstartswith[$message[1];<a];true;gif];false;png]?size=4096) para baixar o emoji **$advancedtextsplit[$message[1];:;2]**]
$image[attachment://$advancedtextsplit[$message[1];:;2].$replaceText[$replaceText[$stringstartswith[$message[1];<a];true;gif];false;png]]
$attachment[https://cdn.discordapp.com/emojis/$advancedtextsplit[$message[1];:;3;>;1].$replaceText[$replaceText[$stringstartswith[$message[1];<a];true;gif];false;png]?size=4096;$advancedtextsplit[$message[1];:;2].$replaceText[$replaceText[$stringstartswith[$message[1];<a];true;gif];false;png]]
$footer[$username;$authorAvatar]

$cooldown[5s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:5s} {deletecommand}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]


$onlyIf[$stringstartswith[$message[1];<]==true;Emoji fornecido inválido ou talvez um emoji padrão seja fornecido, obs: Emoji padrão não pode ser baixado. {deletecommand} {delete:10s}]
$onlyIf[$message[1]!=;**Use:** \`$getServerVar[prefix]emoji <emoji>\`]
`
}