module.exports.command = {
name: "ui", aliases: "userinfo",
code: `
$if[$memberExists[$findUser[$replaceText[$replaceText[●$message●;●●;$authorID];●;];no]]==true]
$reactionCollector[$splitText[1];$authorID;2m;▶️;userinfo;no]
$endif

$textSplit[$sendMessage[{title:**$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$platform[$replaceText[$findUser[$message;yes];$clientID;817857013698265108]];web;🌐];mobile;📱];desktop;💻];none;❓];, ;]$username[$findUser[$message;yes]]**}{footer:$username:$userAvatar[$authorID]}{field:**Discriminador**:\`\`\`\n#$discriminator[$findUser[$message;yes]]\n\`\`\`:yes}{field:**ID**:\`\`\`\n$findUser[$message;yes]\n\`\`\`:yes}{field:**$replaceText[$replaceText[$replaceText[$replaceText[$status[$findUser[$message;yes]];idle;<:idle:821778727091830794>];dnd;<:dnd:829829142861316157>];offline;<:off:829829140885667901>];online;<:online:829829138529386567>] $replaceText[$getCustomStatus[$findUser[$message;yes];emoji];none;] Status**:\`\`\`\n$replaceText[$activity[$findUser[$message;yes]];Custom Status;$getCustomStatus[$findUser[$message;yes];state]]\n\`\`\`:yes}{field:**Conta criada há**:\`\`\`\n$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$creationDate[$findUser[$message;yes];time];months;meses];month;mes];days;dias];day;dia];hours;horas];hour;hora];minutes;minutos];minute;minuto];seconds;segundos];second;segundo];and;e];years;anos];year;ano];weeks;semanas];week;semana]\n\`\`\`:yes}{field:**Entrou há**:\n\`\`\` $replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$memberJoinedDate[$findUser[$message;yes];time];years;anos];year;ano];months;meses];month;mês];weeks;semanas];week;semana];second;segundo];hour;hora];day;dia];minutes;minutos];and;e]\n\`\`\`:yes}
{thumbnail:$userAvatar[$findUser[$message;yes]]}{color:$replaceText[$getRoleColor[$highestRole[$clientID]];000000;FEB1D5]};yes]; ]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]
`
}