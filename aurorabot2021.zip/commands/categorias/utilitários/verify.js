module.exports.command = {
  name: "verify", aliases: ["verificar"],
  code: `✅ <@$authorID>  Você votou em mim no Top.gg e como recompensa ganhou:
  (Você ja votou em mim \`$getGlobalUserVar[upvote]\` vezes)

- \`1000\` Creams;
- \`2\` Likes;

🔔 Vote em mim novamente daqui a 12 horas e verifique seu voto novamente!
  

$setGlobalUserVar[creams;$sum[$getGlobalUserVar[creams];1000]]
$setGlobalUserVar[likes;$sum[$getGlobalUserVar[likes];2]]
$setGlobalUserVar[upvote;$sum[$getGlobalUserVar[upvote];1]]

$if[$getGlobalUserVar[upvote]==20]
<@$authorID>
-> ✅ Você votou em mim e verificou seu voto \`20x\` e como recompensa você ganhou a badge permanente de Upvote <:badgeupvote:851207433917562949> no seu perfil!

$setGlobalUserVar[badgeupvote;<:badgeupvote:851207433917562949>]
$setGlobalUserVar[upvote;$sum[$getGlobalUserVar[upvote];1]]

$endif


$onlyIf[$jsonRequest[https://top.gg/api/bots/$clientID/check?userId=$authorID;voted;error;Authorization:eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6Ijc3Mzc4NDU4Mjg1NTcyMDk2MSIsImJvdCI6dHJ1ZSwiaWF0IjoxNjIyNTIyNDExfQ.O-33wC3UJXKnf1wHTkum26HnG6SDLuGskJAz5hcY9I8]==1; <@$authorID> {description:-> Você não votou em mim no Top.gg, [clicando aqui](https://top.gg/bot/773784582855720961/vote) você é direcionado para a aba de votar em mim

-> **Para receber recompensas a cada 12 horas por ter votado em mim, utilize o comando 
\`$getServerVar[prefix]verificar\` para verificar seu voto!**}{color:$getVar[color]}]

$if[$jsonRequest[https://top.gg/api/bots/$clientID/check?userId=$authorID;voted;error;Authorization:eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6Ijc3Mzc4NDU4Mjg1NTcyMDk2MSIsImJvdCI6dHJ1ZSwiaWF0IjoxNjIyNTIyNDExfQ.O-33wC3UJXKnf1wHTkum26HnG6SDLuGskJAz5hcY9I8]==1]
$addCmdReactions[✅]

$globalCooldown[12h;<@$authorID>, Você confirmou seu voto recentemente, aguarde %time% para verificar novamente!]
$else

$endif
 
 $channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]

  `
}