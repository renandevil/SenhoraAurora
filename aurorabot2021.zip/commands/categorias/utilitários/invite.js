module.exports.command = {
  name: "invite", aliases: ["convidar", "link", "links", "twitter", "convite", "adicionar"],
  code: `$deletecommand
<@$authorID>
  $description[🌟 Olá <@$authorID>, eu me chamo Aurora™, me convide para o seu servidor [clicando bem aqui](https://discord.com/oauth2/authorize?client_id=773784582855720961&scope=bot+applications.commands&permissions=37013568) para que possamos nos divertir ou até ouvir música!
  
💫 Você também pode me ajudar a ficar online, como realizar uma doação de qualquer quantia [clicando aqui](https://donatebot.io/checkout/774053386176823327)

🌺 Caso tenha dúvidas ou achou um erro, você pode entrar em meu [Servidor de Suporte](https://discord.gg/vXvMU3Wcwq) para que minha Desenvolvedora possa conversar com você, e se quiser conversar comigo, vá ao meu [Twitter](https://twitter.com/AuroratmBot?s=09)
]
$footer[$username;$authorAvatar]
$color[#FEB1D5]

$cooldown[20s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:10s} {deletecommand}]
`
}