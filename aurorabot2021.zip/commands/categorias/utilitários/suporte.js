module.exports.command = {
  name: "suporte", aliases: ["support", "servidordesuporte"],
  code: `$deletecommand
<@$authorID>
  $title[<:auroratm:845422854065618954> Aurora™ Support]
  $description[💗 Olá <@$authorID>, Entre no meu servidor de suporte [clicando aqui](https://discord.gg/vXvMU3Wcwq) para receber ajuda da minha desenvolvedora ou relatar erros e bugs.

💫 Além disso, no meu [servidor de suporte](https://discord.gg/vXvMU3Wcw) você também pode criar e enviar fanarts, avaliar a bot dizendo o que mais gostou ou o que pode ter/melhorar, e receber updates e saber do status atual da Aurora™ diretamente no seu servidor!]
$color[#FEB1D5]
$footer[$username;$authorAvatar]

$cooldown[15s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:10s} {deletecommand}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]
`
}