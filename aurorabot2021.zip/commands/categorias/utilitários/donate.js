module.exports.command = {
  name: "donate", aliases: ["doação", "doar"],
  code: `$deletecommand
  
  $title[Donate]
  $description[💰 Olá <@$authorID>, gostaria de realizar um donate para me manter online e estável? isso iria me ajudar demais a crescer no discord e aprimorar meus comandos e agilidades, sabia? [clicando aqui](https://donatebot.io/checkout/774053386176823327) você pode realizar donate via cartão, mas eu prefiro pix, pq é mais rápido haha!
  
**Doe via Pix**
Chave, E-mail: \`luzersousa8799@gmail.com\`]
$color[#FEB1D5]
$footer[$username;$authorAvatar]

$cooldown[10s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:10s} {deletecommand}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]`
}