module.exports.command = {
	name: "ping",
	code: `Ping uu
	$editIn[0s;
$customEmoji[senhora_pong] **Pong!** <@$authorID>
📡 **Ping:** \`$pingms\`
🛰️ **API:** \`$botPingms\`
⏳ **Uptime:** \`$uptime\`]
	$deletecommand
	
$cooldown[5s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:5s} {deletecommand}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]
	
$setVar[comandos;$sum[$getVar[comandos];1]]`
}