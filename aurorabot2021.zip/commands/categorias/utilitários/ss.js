module.exports.command = {
name: "ss", aliases: ["screenshoot"],
code: `$attachment[https://api.apiflash.com/v1/urltoimage?access_key=29f48d3060224acc851647ff4179f878&url=$message]
$onlyPerms[manageserver;Você precisa da permissão de gerenciar servidor para poder utilizar este comando!]

$setVar[comandos;$sum[$getVar[comandos];1]]`
}