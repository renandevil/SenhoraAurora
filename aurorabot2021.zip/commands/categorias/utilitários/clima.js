module.exports.command = {
  name: "clima", aliases: ["weather"],
code: `$deletecommand

$title[<a:nuvenzinha:829829133458079774> | Clima em $message] 
$description[
**Localização:** \`$jsonRequest[http://api.somecool.repl.co/weather?place=$message;location;]\`
**Temperatura:** \`$jsonRequest[http://api.somecool.repl.co/weather?place=$message;temperature;]\`
**Umidade:** \`$jsonRequest[http://api.somecool.repl.co/weather?place=$message;humidity;]°\`

**Velocidade do tempo:** \`$jsonRequest[http://api.somecool.repl.co/weather?place=$message;wind_speed;]\`
**Velocidade do vento:** \`$jsonRequest[http://api.somecool.repl.co/weather?place=$message;wind_display;]\`
**Tempo de observação:** \`$jsonRequest[http://api.somecool.repl.co/weather?place=$message;observation_time;]\`
]
$argsCheck[>1;Utilize o comando com um local para saber o clima/temperatura do local dito. {deletecommand} {delete:10s}]
$color[#FEB1D5]
$footer[$username;$authorAvatar]

$cooldown[5s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:5s} {deletecommand}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]

$setVar[comandos;$sum[$getVar[comandos];1]]`
}