module.exports.command = {
  name: "perfil", aliases: ["prof", "profile", "procfile"],
  code: `$deletecommand
  <@$authorID>
  $footer[$username;$authorAvatar]
  $thumbnail[$userAvatar[$mentioned[1;yes]]]
  $title[$getGlobalUserVar[badgeupvote;$mentioned[1;yes]] $getGlobalUserVar[badgepride;$mentioned[1;yes]] $username[$mentioned[1;yes]]'s - Perfil;$userAvatar[$mentioned[1;yes]]]

$addField[**Biografia:**;
\`$getGlobalUserVar[bio;$mentioned[1;yes]]\`

**Background:**]
$addField[💍 **Casado com:**;
\`(Ainda em Construção)\`]
$addField[<:creams:829853319405109318> **Creams:**;
\`$getGlobalUserVar[creams;$mentioned[1;yes]]\`]
$addField[
❤️ **Likes:**;
\`$getGlobalUserVar[likes;$mentioned[1;yes]]\`]

$image[$getGlobalUserVar[background;$mentioned[1;yes]]]
  $color[#FEB1D5]
  
$cooldown[10s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:10s} {deletecommand}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]
 `
}