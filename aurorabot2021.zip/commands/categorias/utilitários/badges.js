module.exports.command = {
  name: "badges", aliases: ["medalhas", "badge"],
  code: `<@$authorID>
$author[🏅 Badges]
$description[-> Badges permanente ou por tempo limitado que podem ser adquiridas para o seu perfil atual:]

$addField[**Limitado:**; 🌈 **Pride**
-> \`Utilize o comando $getServerVar[prefix]verificar para ganhar esta badge do evento June Month\`;]

$addField[**Permanente:**;-> <:badgeupvote:851207433917562949> Upvote
-> \`Vote em mim e utilize o comando $getServerVar[prefix]verificar 20x\`;]
$color[$getVar[color]]
$footer[$username;$authorAvatar]
 
$cooldown[10s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:10s} {deletecommand}]
 
 $channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]
  
  
  `
}