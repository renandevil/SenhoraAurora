module.exports.command = {
  name: "say", aliases: ["falar"],
  code: `$description[$message]

$footer[$username;$authorAvatar]


$onlyPerms[managemessages;Você não tem a permissão__Gerenciar Mensagens__ para utilizar este comando!{deletecommand} {delete:10s}]
$onlyIf[$noMentionMessage=<200;{description:Eu só consigo falar até um máximo de 200 mensagens por comando!}{deletecommand} {delete:10s} {color: FEB1D5}]
$onlyIf[$noMentionMessage=>3;{description:Eu só falo se a menssagem conter mais de 2 caracteres!}{deletecommand} {delete:10s} {color: FEB1D5}]
$argsCheck[>1;{description: Você precisa escrever alguma coisa para que eu possa falar!} {deletecommand} {delete:10s} {color: FEB1D5}]
$color[#FEB1D5]

$cooldown[5s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:5s} {deletecommand}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]

$setVar[comandos;$sum[$getVar[comandos];1]]`
}