module.exports.command = {
  name: "upvote", aliases: ["votar", "vote", "voto", "top.gg", "topgg"],
  code: `$deletecommand
  
  $title[Upvote]
  $description[<:topgg:843580490514825276> Olá, sabia que você pode me ajudar a crescer mais e mais na comunidade do discord apenas votando em mim? [clicando aqui](https://top.gg/bot/773784582855720961/vote) você é redirecionado a um site para votar em mim, além disso, você pode receber recompensas como Creams e Likes!
  
**-> Utilize \`$getServerVar[prefix]verificar\`  depois de votar em mim para coletar recompensas!**

-> <a:topgg_2:843580389306138714> \`(Você ja votou em mim $getGlobalUserVar[upvote]x), votando em mim 20x você ganha a badge permanente de upvote\`<:badgeupvote:851207433917562949>]

$color[#FEB1D5]
$footer[$username clique no nome azul;$authorAvatar]

$cooldown[10s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:10s} {deletecommand}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]`
}