module.exports.command = {
 name: "avatar",
 aliases: ['av', 'avt'],
 code: `
 $deletecommand
 $color[FEB1D5]
 $title[$getGlobalUserVar[badgeupvote;$findUser[$message]] $getGlobalUserVar[badgepride;$findUser[$message]] - $username[$findUser[$message]]'s Avatar]
 $image[$userAvatar[$findUser[$message]]]
 $footer[$username;$authorAvatar]

$cooldown[5s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:5s} {deletecommand}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]
`
}