module.exports.command = {
  name: "biografia", aliases: ["bio", "aboutme"],
  code: `$deletecommand
  
  $author[✅ Biografia Setada com Sucesso!]
  $description[Você setou sua biografia para \`$message\`, verifique seu $getServerVar[prefix]perfil]
  $color[FEB1D5]
  
  $setGlobalUserVar[bio;$message]
  
  $globalCooldown[30s;{description:⏰ $username Espere %time% para setar uma nova biografia!} {color:#FEB1D5} {deletecommand} {delete:10s}]
  
  $onlyIf[$charCount[$message]<150;Você só pode definir uma biografia em até \`150\` caracteres, e a sua mensagem contém \`$charCount[$message]\` {deletecommand} {delete:10s}]

  $argsCheck[>1;Escreva algo para setar a biografia de seu perfil{delete:5s}]
  
$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]
 `
}