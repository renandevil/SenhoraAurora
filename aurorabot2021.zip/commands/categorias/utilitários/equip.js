module.exports.command = {
  name: "equip", aliases: "equipar",
  code: `$author[Equip - (beta)]
$description[-> Equipe um background que você tenha, caso não tiver um, compre na \`$getServerVar[prefix]loja\`!

$replaceText[$replaceText[$checkCondition[$getGlobalUserVar[bg2]==true];true;<:A_ligado:791038425326420018>];false;<:A_desligado:791063885133905951>] - \`1\` - **Fortnite**
$replaceText[$replaceText[$checkCondition[$getGlobalUserVar[bg33]==true];true;<:A_ligado:791038425326420018>];false;<:A_desligado:791063885133905951>] - \`2\` - **Rocket League**
$replaceText[$replaceText[$checkCondition[$getGlobalUserVar[bg4]==true];true;<:A_ligado:791038425326420018>];false;<:A_desligado:791063885133905951>] - \`3\` - **Your Name**
$replaceText[$replaceText[$checkCondition[$getGlobalUserVar[bg5]==true];true;<:A_ligado:791038425326420018>];false;<:A_desligado:791063885133905951>] - \`4\` - **Your Name2**
$replaceText[$replaceText[$checkCondition[$getGlobalUserVar[bg6]==true];true;<:A_ligado:791038425326420018>];false;<:A_desligado:791063885133905951>] - \`5\` - **Padrão Rosa**
||Irei botar mais depois||

-> Utilize: \`$getServerVar[prefix]equip **<ID>**\`
Exemplo: \`$getServerVar[prefix]equip 1\`
]
$color[$getVar[color]]
  
$if[$checkcontains[$message;1]==true]

<@$authorID>
✅ Background **Fortnite** equipado com sucesso!

-> Verifique seu \`$getServerVar[prefix]perfil\`

$setGlobalUserVar[background;https://cdn.discordapp.com/attachments/829829137455644712/852050997790244864/068bbfa93b669bb6574506ad0a328b05.jpg]

$onlyIf[$getGlobalUserVar[bg2]==true;{description: **Você não tem este background!**
-> Compre um na \`$getServerVar[prefix]loja\`}{color: FEB1D5} {deletecommand} {delete:10s}]

$endif

$if[$checkcontains[$message;2]==true]

<@$authorID>
✅ Background **Rocket League** equipado com sucesso!

-> Verifique seu \`$getServerVar[prefix]perfil\`

$setGlobalUserVar[background;https://cdn.discordapp.com/attachments/829829137455644712/852053896573747230/57ec1366a32837474150eef96084d428.jpg]
$onlyIf[$getGlobalUserVar[bg33]==true;{description: **Você não tem este background!**
-> Compre um na \`$getServerVar[prefix]loja\`}{color: FEB1D5} {deletecommand} {delete:10s}]

$endif

$if[$checkcontains[$message;3]==true]

<@$authorID>
✅ Background **Your Name** equipado com sucesso!

-> Verifique seu \`$getServerVar[prefix]perfil\`

$setGlobalUserVar[background;https://cdn.discordapp.com/attachments/829829137455644712/852053897228714014/319bde4795e37fb0d0560b02cdc063e5.jpg]

$onlyIf[$getGlobalUserVar[bg4]==true;{description: **Você não tem este background!**
-> Compre um na \`$getServerVar[prefix]loja\`}{color: FEB1D5} {deletecommand} {delete:10s}]

$endif

$if[$checkcontains[$message;4]==true]

<@$authorID>
✅ Background **Your Name2** equipado com sucesso!

-> Verifique seu \`$getServerVar[prefix]perfil\`

$setGlobalUserVar[background;https://cdn.discordapp.com/attachments/829829137455644712/852053897081782302/3f5401cec271f1b97b12b7f8eb78a434.jpg]

$onlyIf[$getGlobalUserVar[bg5]==true;{description: **Você não tem este background!**
-> Compre um na \`$getServerVar[prefix]loja\`}{color: FEB1D5} {deletecommand} {delete:10s}]

$endif

$if[$checkcontains[$message;5]==true]

<@$authorID>
$description[✅ Background **Padrão Rosa** equipado com sucesso!

-> Verifique seu \`$getServerVar[prefix]perfil\`]
$color[$getVar[color]]

$setGlobalUserVar[background;https://cdn.discordapp.com/attachments/780281654211117097/824131187366559765/rosafundopreto.png]

$endif

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]
  `
}