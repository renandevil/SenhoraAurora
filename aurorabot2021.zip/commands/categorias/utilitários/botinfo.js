module.exports.command = {
 name: "botinfo", aliases: ["bot", "infobot"],
 code: `$deletecommand
 <@$authorID>
 $thumbnail[$userAvatar[773784582855720961]]
 $author[Aurora™ - Bot Info]
 $description[🌺 Olá <@$authorID>, sou uma bot multifuncional com comandos de administração, utilitários, diversão, economia, música e muito configurável!]

$addField[🌎 **Estatísticas**;
Servidores: \`$serverCount\`
Usuários: \`$AllMembersCount\`
Versão atual: \`$getVar[versao]\`
Latência atual: \`$pingms\`
Tempo online: \`$uptime\`

$createObject[{}]
[Me Adicione](https://discord.com/oauth2/authorize?client_id=773784582855720961&scope=bot+applications.commands&permissions=37013568) | [Vote em mim](https://top.gg/bot/773784582855720961/vote) | [Servidor de Suporte](https://discord.gg/vXvMU3Wcwq)]

$addField[🔧 **Informações**;
 
Criada por: \`Senhora ?#6151\`
Criada em: \`5 de Nov, 2020 às 02:43\`
Criada na livraria [Aoi.js](https://aoi.js.org/) e [Discord.js](https://discord.js.org/#/)
Avatar feito por: [@tubarururu](https://twitter.com/tubarururu?s=09)]
 
$addField[Anúncios;$getVar[ads]]

 $footer[$username;$authorAvatar]
 $color[#FEB1D5]
 
$cooldown[10s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:10s} {deletecommand}]
 
 $channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]
`
}