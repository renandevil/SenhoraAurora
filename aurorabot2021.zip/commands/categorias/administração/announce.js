module.exports.command = {
name: "announce", aliases: "embed",
code: `<@$authorID>
$title[$splitText[1]]
$description[$splitText[2]]
$footer[$splitText[3]]
$color[
$replaceText[$replaceText[$checkCondition[$splitText[3]== ];true;$getVar[color]];false;$splitText[3]]
$textSplit[$message;|]
$argsCheck[>1;{description: Utilize da maneira correta, separando com **|** em formato de embed, exemplo:
 
 \`título\` | \`descrição\` | \`footer\` | \`cor\`
outro exemplo:

Oiee | eu me chamo Aurora™ | tenha um bom dia! | #FF008B
} {deletecommand} {delete:20s} {color: FEB1D5}]

$onlyPerms[admin; Você não tem permissão de \`Administrador\` para esse comando {deletecommand} {delete:5s}]
$deleteCommand`
}