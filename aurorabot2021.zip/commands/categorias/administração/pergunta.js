module.exports.command = {
 name: "enquete", aliases: "poll",
 code: `
 $title[📊 Nova Enquete]
 $color[$getVar[color]]
 $addField[2️⃣ Opção 2;\`$splitText[3]\`]
 $addField[1️⃣ Opção 1;\`$splitText[2]\`]
 $addField[❔ Pergunta; \`$splitText[1]\`]
 $footer[$username;$authorAvatar]
 $addReactions[1️⃣;2️⃣]
 
 $onlyPerms[managemessages; Você precisa da permissão \`Gerenciar menssagens\` para utilizar este comando! {deletecommand}{delete:8s}]
 $textSplit[$noMentionMessage;/]
 
 $argsCheck[>1;**Use:**
 \`$getServerVar[prefix]enquete pergunta/opção 1/opção 2\`
 **Exemplo:**
 \`$getServerVar[prefix]enquete Biscoito ou bolacha?/Biscoito/Bolacha\`
 **Como ficaria:**
 ❔ **Pergunta:**
 \`Biscoito ou bolacha?\`
 1️⃣ **Opção 1**
 \`biscoito\`
 2️⃣ **Opcão 2:**
 \`bolacha\` {deletecommand}{delete:20s}]
 `
}