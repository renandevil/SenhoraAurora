module.exports.command = {
name: "lock",
code: `$deletecommand
$sendmessage[<@$authorID>{author:Lock Chat}{description: ✅ Canal <#$findchannel[$message[1]]> **Bloqueado** por <@$authorID>!}{color:FF008B};no]

$modifyChannelPerms[$findchannel[$message[1]];-sendmessages;$guildID]

$cooldown[10s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:10s} {deletecommand}]

$onlyIf[$checkcontains[$channelpermissionsfor[$clientid];Embed Links;Manage Channels]==true;{description:Eu não tenho permissões de **Gerenciar Canais** / **Embed Links** para isto} {deletecommand} {delete:10s}]

$onlyperms[managechannels; {description:Você não tem a permissão **Gerenciar Canais**!}{deletecommand} {delete:10s}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]`
}