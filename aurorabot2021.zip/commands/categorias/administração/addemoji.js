module.exports.command = {
 name: "addemoji",
 aliases: "ad",
 code: `$deletecommand
 <@$authorID> Emoji $addEmoji[https://cdn.discordapp.com/emojis/$replaceText[$replaceText[$checkCondition[$checkContains[$message[1];<]$checkContains[$message[1];:]$checkContains[$message[1];>]==truetruetrue]$isNumber[$message[1]];truefalse;$replaceText[$advancedTextSplit[$message[1];:;3];>;]];falsetrue;$message[1]];$message[2];yes] Adicionado **$message[2]**
 $onlyIf[$charCount[$message[2]]>=2; Especifique o nome do emoji, que seje maior que \`2 caracteres\` {deletecommand} {delete:5s}]
 $onlyIf[$message[2]!=;**Use**:
 \`\`\`addemoji <emoji | emojiID> <nome pro emoji>\`\`\`]
$onlyPerms[manageemojis; Você não tem permissão de __Gerenciar Emojis__ para esse comando {deletecommand} {delete:5s}]
$onlyBotPerms[manageemojis; Eu não tenho permissão de __Gerenciar Emojis__ para esse comando {deletecommand} {delete:5s}]
$suppressErrors`
}