module.exports.command = {
 name: "kick", aliases: "expulsar",
 code: `$deletecommand

$setUserVar[kick;$sum[$getUserVar[kick;$authorID];1];$authorID]

<@$authorID>
$title[✅ Usuário Expulso com Sucesso]
$color[FF008B]
$description[$username[$findUser[$message[1]]] Foi expulso(a) com Sucesso, você ja expulsou \`$getUserVar[kick]\` Usuários!
-> Motivo: \`$replaceText[$replaceText[$checkCondition[$noMentionMessage==];true;Não especificado];false;$noMentionMessage]\`]
$footer[$username;$authorAvatar]

$kick[$findUser[$message[1]]]

$sendDM[$findUser[$message[1]]; {title: Você foi expulso(a)!} {description:
**Moderador:** \`$username\`
**Servidor:** \`$serverName\`
**Motivo:** \`$replaceText[$replaceText[$checkCondition[$noMentionMessage==];true;Não especificado];false;$noMentionMessage]\`
}{color:FF008B}]

$wait[2s]

$onlyPerms[kick; Você não tem a permissão de \`Expulsar\` para utilizar este comando {deletecommand} {delete:5s}]

$onlyIf[$findUser[$message[1]]!=$authorID;{description: Você não pode expulsar você mesmo}{color: FEB1D5} {deletecommand} {delete:5s}]

$argsCheck[>1;{description:**Use:**
\`$getServerVar[prefix]kick @user <Motivo (opcional)>\`
}{color: FEB1D5} {deletecommand} {delete:5s}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]`
}