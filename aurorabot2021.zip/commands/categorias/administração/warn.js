module.exports.command = {
 name: "warn", aliases: "avisar",
 code: `$deletecommand

$setUserVar[warn;$sum[$getUserVar[warn;$authorID];1];$authorID]

<@$authorID>
$title[✅ Usuário Avisado com Sucesso]
$color[FF008B]
$description[$username[$mentioned[1]] Recebeu 1 aviso com Sucesso, agora ele(a) tem \`$getUserVar[warn;$mentioned[1]] Avisos!\`
-> Motivo: \`$replaceText[$replaceText[$checkCondition[$noMentionMessage==];true;Não especificado];false;$noMentionMessage]\`]
$footer[$username;$authorAvatar]

$sendDM[$mentioned[1]; {title: Você recebeu um aviso!} {description:
**Moderador:** \`$username\`
**Servidor:** \`$serverName\`
**Motivo:** \`$replaceText[$replaceText[$checkCondition[$noMentionMessage==];true;Não especificado];false;$noMentionMessage]\`
-> Agora você tem \`$getUserVar[warn;$mentioned[1]]\` Avisos}{color:FF008B}]

$wait[2s]

$setUserVar[warn;$sum[$getUserVar[warn;$mentioned[1]];1];$mentioned[1]]

$onlyIf[$isBot[$mentioned[1]]==false;{description: Você não pode dar warns para um bot}{color: FEB1D5} {deletecommand} {delete:5s}]

$onlyIf[$mentioned[1]!=$authorID;{description: Você não pode dar warn a si mesmo}{color: FEB1D5} {deletecommand} {delete:5s}]

$onlyPerms[kick; Você não tem a permissão de \`Expulsar\` para utilizar este comando {deletecommand} {delete:5s}]

$argsCheck[>1;{description:**Use:**
\`$getServerVar[prefix]warn @user <Motivo (opcional)>\`
}{color: FEB1D5} {deletecommand} {delete:5s}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]`
}