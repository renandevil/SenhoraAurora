module.exports.command = {
  name: "modstats", aliases: "modstatus",
  code: `$deletecommand
  <@$authorID>
  $deletecommand
  $title[Modstats]
  $description[-> Suas estatísticas/punições dadas por você como moderador neste server:]
  $addField[Avisos;$getUserVar[warn]]
  $addField[Expulsões;$getUserVar[kick]]
  $addField[Banimentos;$getUserVar[ban]]
  $color[FF008B]
$footer[$username;$authorAvatar]

  `
}