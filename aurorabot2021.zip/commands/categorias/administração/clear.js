module.exports.command = {
 name: "clear", aliases: ["purge"],
 code: `$deletecommand
<@$authorID>
 $author[Clear Purge]
$description[<a:popcat:829829155176448021> **Pronto, \`$message[1] Menssagens\` foram apagadas!**]
$clear[$message[1]]
$color[FF008B]

$cooldown[15s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:10s} {deletecommand}]
$footer[$username;$authorAvatar]

$suppressErrors[**Use:** \`$getServerVar[prefix]clear <número>\` {delete:10s}{deletecommand}]

$onlyIf[$noMentionMessage<=500; **Você só pode apagar de 2-500 menssagens por comando** {delete:10s}{deletecommand}]

$onlyIf[$noMentionMessage>=2;**Você só pode apagar de 2-500 menssagens por comando** {delete:10s}{deletecommand}]

$onlyIf[$noMentionMessage!=;** Coloque um número para eu apagar as mensagens**, **Use:** \`$getServerVar[prefix]clear <número>\` {delete:10s}{deletecommand}]

$onlyIf[$isNumber[$noMentionMessage]==true;Coloque um número válido para eu apagar as menssagens
 **Use:** \`$getServerVar[prefix]clear <número>\` {delete:10s}{deletecommand}]

$onlyIf[$message[1]!=;**Use:** \`$getServerVar[prefix]clear <número>\`
-> Que irei apagar uma quantidade de menssagens neste canal.]
$onlyBotPerms[managemessages;**Eu não tenho a permissão \`**Gerenciar Menssagens**\` para isto** {delete:10s}{deletecommand}]
$onlyPerms[managemessages;**Você não tem a permissão** \`**Gerenciar Menssagens**\` {delete:10s}{deletecommand}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]`
}