module.exports.command = {
name: "unlock",
code: `$deletecommand
$sendmessage[<@$authorID>{author:Unlock Chat}{description:✅ Canal <#$findchannel[$message[1]]> **Desbloqueado** por <@$authorID>!}{color:FF008B};no]

$modifyChannelPerms[$findchannel[$message[1]];/sendmessages;$guildID]

$cooldown[10s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:10s} {deletecommand}]

$onlyif[$checkcontains[$channelpermissionsfor[$clientid];Embed Links;Manage Channels]==true;Eu não tenho permissões de **Gerenciar Canais** ou **Embed Links** para isto {deletecommand} {delete:10s}]

$onlyperms[managechannels; Você não tem a permissão **Gerenciar Canais**! {deletecommand} {delete:10s}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]`
}