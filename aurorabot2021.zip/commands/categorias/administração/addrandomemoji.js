module.exports.command = {
  name: "addrandomemoji",
  code: `$title[📥 Emoji Aleatório Adicionado]
  $description[Adicione uma variedades de emojis diferentes no seu servidor!! Veja a lista de emojis agora que eu acabei de adicionar um novo!❤️ caso não goste, exclua manualmente.]
 $color[#FEB1D5] 
  
  $addEmoji[$splitText[1];$splitText[2]]
$textSplit[$jsonRequest[https://api.meowee.cf/api/random/randomemoji?;emoji;];|]

$onlyPerms[manageemojis; Você não tem permissão de __Gerenciar Emojis__ para esse comando {deletecommand} {delete:5s}]
$onlyBotPerms[manageemojis; Eu não tenho permissão de __Gerenciar Emojis__ para esse comando {deletecommand} {delete:5s}]
$suppressErrors[Eita, algo deu errado, provavelmente ou o comando não está funcionando, ou, não ah mais espaço para novos emojis. {delete:10s}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]`
}