module.exports.command = {
 name: "ban", aliases: "banir",
 code: `$deletecommand
 
$setUserVar[ban;$sum[$getUserVar[ban;$authorID];1];$authorID]
 
<@$authorID>
$title[✅ Usuário Banido com Sucesso]
$color[FF008B]
$description[$username[$findUser[$message[1]]] Foi banido com Sucesso, você já baniu \`$getUserVar[ban]\` Usuários!
-> Motivo: \`$replaceText[$replaceText[$checkCondition[$noMentionMessage==];true;Não especificado];false;$noMentionMessage]\`]
$footer[$username;$authorAvatar]

$ban[$findUser[$message[1]]]

$sendDM[$findUser[$message[1]]; {title: Você foi banido(a)!} {description:
**Moderador:** \`$username\`
**Servidor:** \`$serverName\`
**Motivo:** \`$replaceText[$replaceText[$checkCondition[$noMentionMessage==];true;Não especificado];false;$noMentionMessage]\`
}{color:FF008B}]

$wait[2s]

$onlyIf[$findUser[$message[1]]!=$authorID;{description: Você não pode banir você mesmo}{color: FEB1D5} {deletecommand} {delete:5s}]

$onlyPerms[ban; Você não tem a permissão de \`Banir\` para utilizar este comando {deletecommand} {delete:5s}]

$argsCheck[>1;{description:**Use:**
\`$getServerVar[prefix]ban @user <Motivo (opcional)>\`
}{color: FEB1D5} {deletecommand} {delete:5s}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]`
}