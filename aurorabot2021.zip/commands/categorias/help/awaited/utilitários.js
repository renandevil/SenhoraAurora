module.exports.awaitedCommand = {
name: "utl",
code: `$editMessage[$message[1];<@$authorID>{title:<:auroratm:845422854065618954> - Painel de ajuda - $username[$clientID]}{field:Anúncios:$getVar[ads]}{field:Links:[Me convide](https://discord.com/oauth2/authorize?client_id=773784582855720961&scope=bot+applications.commands&permissions=37013568) | [Vote em mim](https://top.gg/bot/773784582855720961/vote) | [Servidor de Suporte](https://discord.gg/vXvMU3Wcwq)}{field:⚒️ **Comandos de utilitários**:

\`$getServerVar[prefix]avatar\` - Baixe a foto de alguém.
\`$getServerVar[prefix]emoji\` - Baixe um emoji.
\`$getServerVar[prefix]userinfo\` - Veja informações de um usuário.
\`$getServerVar[prefix]roleinfo\` - Veja informações de um cargo.
\`$getServerVar[prefix]serverinfo\` - Veja algumas informações do servidor atual.
\`$getServerVar[prefix]invites\` - Veja quantos usuários você ja convidou para o servidor.
\`$getServerVar[prefix]clima\` - Veja o clima de alguma cidade.
\`$getServerVar[prefix]say\` - Faça a bot dizer algo por você.\n}{field:
**Bot**:
\`$getServerVar[prefix]ping\` - Veja a latência atual.
\`$getServerVar[prefix]botinfo\` - Veja informações sobre a bot.
\`$getServerVar[prefix]donate\` - Doe para a bot ficar online.
\`$getServerVar[prefix]invite\` - Convide a bot para o seu servidor.
\`$getServerVar[prefix]upvote\` - Vote na bot no topgg.
\`$getServerVar[prefix]suporte\` - Entre no servidor de suporte oficial da bot.}{image:https://cdn.discordapp.com/attachments/829829138185060352/854168084591804416/PicsArt_06-14-10.11.23.jpg}{footer:$username:$authorAvatar}{color:$getVar[color]}]`
}
//https://cdn.discordapp.com/attachments/829829138185060352/854168084591804416/PicsArt_06-14-10.11.23.jpg