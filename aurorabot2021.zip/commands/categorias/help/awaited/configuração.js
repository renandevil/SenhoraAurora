module.exports.awaitedCommand = {
name: "con",
code: `$editMessage[$message[1];<@$authorID>{title:<:auroratm:845422854065618954> - Painel Configurável - $username[$clientID]}{field:Anúncios:$getVar[ads]}{field:Links:[Me convide](https://discord.com/oauth2/authorize?client_id=773784582855720961&scope=bot+applications.commands&permissions=37013568) | [Vote em mim](https://top.gg/bot/773784582855720961/vote) | [Servidor de Suporte](https://discord.gg/vXvMU3Wcwq)}{field:⚙️ **Configuração**:\`$getServerVar[prefix]set-prefix\` - Muda o prefixo \`$getServerVar[prefix]\` da Aurora™.
\`$getServerVar[prefix]set-autorole\` - Seta um cargo para eu colocar em todos os membros novos que entrarem no servidor.
\`$getServerVar[prefix]set-welcome\` - Seta um canal para eu dar boas-vindas aos novos membros.
\`$getServerVar[prefix]set-leave\` - Seta um canal para eu alertar quem saiu do servidor.}{image:https://cdn.discordapp.com/attachments/829829138185060352/854169242840334356/PicsArt_06-14-10.11.09.jpg}{footer:$username:$authorAvatar}{color:#FEB1D5}]
$suppressErrors[]`
}