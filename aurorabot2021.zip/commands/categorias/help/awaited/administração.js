module.exports.awaitedCommand = {
name: "adm",
code: `$editMessage[$message[1];<@$authorID>{title:<:auroratm:845422854065618954> - Painel de ajuda - $username[$clientID]}{field:Anúncios:$getVar[ads]}{field:Links:[Me convide](https://discord.com/oauth2/authorize?client_id=773784582855720961&scope=bot+applications.commands&permissions=37013568) | [Vote em mim](https://top.gg/bot/773784582855720961/vote) | [Servidor de Suporte](https://discord.gg/vXvMU3Wcwq)}{field:👮 **Comandos de administração**:

\`$getServerVar[prefix]ban\` - Bane um usuário do servidor.
\`$getServerVar[prefix]kick\` - Expulsa um usuário.
\`$getServerVar[prefix]warn\` - da um alerta em um usuário no privado.
\`$getServerVar[prefix]modstats\` - Veje suas estatísticas como moderador no servidor.
\`$getServerVar[prefix]lock\` - Bloqueia o chat para ninguém enviar menssagens.
\`$getServerVar[prefix]unlock\` - Deixa o chat aberto para todos os usuários.
\`$getServerVar[prefix]clear\` - Apaga uma certa quantia de menssagens no chat.
\`$getServerVar[prefix]addrandomemoji\` - Adicione um emoji novo aleatório que nem você sabe.
\`$getServerVar[prefix]addemoji\` - Adicione um emoji utilizando ele ou usando o id dele.
\`$getServerVar[prefix]announce\` - Crie uma embed no chat.
\`$getServerVar[prefix]enquete\` - Abra uma enquete no chat.\n}{image:https://cdn.discordapp.com/attachments/829829138185060352/854168084302659594/PicsArt_06-14-10.10.12.jpg}{footer:$username:$authorAvatar}{color:#FEB1D5}]`
}