module.exports.awaitedCommand = {
name: "eco",
code: `$editMessage[$message[1];<@$authorID>{title:<:auroratm:845422854065618954> - Painel de ajuda - $username[$clientID]}{field:Anúncios:$getVar[ads]}{field:Links:[Me convide](https://discord.com/oauth2/authorize?client_id=773784582855720961&scope=bot+applications.commands&permissions=37013568) | [Vote em mim](https://top.gg/bot/773784582855720961/vote) | [Servidor de Suporte](https://discord.gg/vXvMU3Wcwq)}{field: 💰 **Comandos de economia**:

\`$getServerVar[prefix]claimall\` - Veja todos seus cooldowns em andamento.
\`$getServerVar[prefix]daily\` - Pegue seu prêmio diário.
\`$getServerVar[prefix]minerar\` - Minere e ganhe recompensas.
\`$getServerVar[prefix]pescar\` - Pesque e ganhe recompensas.
\`$getServerVar[prefix]loja\` - Veja a loja de itens e equipamentos.
\`$getServerVar[prefix]perfil\` - Veja seu perfil na bot.
\`$getServerVar[prefix]biografia\` - Muda a biografia do seu perfil.
\`$getServerVar[prefix]curtir\` - Curta um perfil enviando 1 like.
\`$getServerVar[prefix]badges\` - Veja emblemas exclusivos para seu perfil.
\`$getServerVar[prefix]equip\` - Equipe backgrounds comprados na loja.
\`$getServerVar[prefix]buy\` - Compre itens, equipamentos, backgrounds, etc.
\`$getServerVar[prefix]vender\` - Venda seus itens da sua mochila.
\`$getServerVar[prefix]mochila\` - Veja todos seus itens e equipamentos.
\`$getServerVar[prefix]balance\` - Veja quantos creams você tem.
\`$getServerVar[prefix]pay\` - Pague para um amigo(a).
\`$getServerVar[prefix]top\`- Veja o ranking global de creams.
\`$getServerVar[prefix]top-likes\` - Veja o top ranking global de likes.
\`$getServerVar[prefix]verificar\` - Verifique seu voto e ganhe recompensas.
\`$getServerVar[prefix]notificar\` - Irei lhe lembrar de minerar e pescar.\n}{image:https://cdn.discordapp.com/attachments/829829138185060352/854168779180998656/PicsArt_06-14-10.10.55.jpg}{footer:$username:$authorAvatar}{color:#FEB1D5}]`
}