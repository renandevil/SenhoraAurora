module.exports.awaitedCommand = {
name: "div",
code: `$editMessage[$message[1];<@$authorID>{title:<:auroratm:845422854065618954> - Painel de ajuda - $username[$clientID]}{field:Anúncios:$getVar[ads]}{field:Links:[Me convide](https://discord.com/oauth2/authorize?client_id=773784582855720961&scope=bot+applications.commands&permissions=37013568) | [Vote em mim](https://top.gg/bot/773784582855720961/vote) | [Servidor de Suporte](https://discord.gg/vXvMU3Wcwq)}{field:😍 **Comandos de diversão**:

\`$getServerVar[prefix]kiss\` - Beije algum amigo(a).
\`$getServerVar[prefix]hug\` - Abrace algum amigo(a).
\`$getServerVar[prefix]slap\` - De um tapa em algum amigo(a).
\`$getServerVar[prefix]dado\` - Jogue um dado e veja que número vai parar.
\`$getServerVar[prefix]ascii\` - Deixe uma palavra bonita.
\`$getServerVar[prefix]meme\` - Pesquise um meme no reddit.\n}{field:**Imagens**: \`$getServerVar[prefix]cat\` - Fotos de gatinhos.
\`$getServerVar[prefix]dog\` - Fotos de cachorros.
\`$getServerVar[prefix]panda\` - Fotos de pandas.
\`$getServerVar[prefix]bird\` - Fotos de passarinhos.
\`$getServerVar[prefix]milkyou\` - Um cara falando que precisa ordenar um usuário.
}{image:https://cdn.discordapp.com/attachments/829829138185060352/854168778472292352/PicsArt_06-14-10.10.41.jpg}{footer:$username:$authorAvatar}{color:#FEB1D5}]`
}