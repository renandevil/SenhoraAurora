module.exports.awaitedCommand = {
name: "welcome2",
code: `$deleteMessage[$channelID;$splitText[1]]
$wait[20s]
$textSplit[$sendMessage[✅ welcome setado para $message com sucesso!;yes]]
$editMessage[$getUserVar[welcome];{title:<:cafezinho:791553695258116107> | Painel de ajuda -  $username[$clientID]}{field:__Informações__:Prefixo nesse servidor: \`$getServerVar[prefix]\`}{field:__Links__:*[Me convide](https://discord.com/oauth2/authorize?client_id=773784582855720961&scope=bot+applications.commands&permissions=37013568)* | *[Vote em mim](https://top.gg/bot/773784582855720961/vote)* | *[Servidor de Suporte](https://discord.gg/vXvMU3Wcwq)*}{field:**__Configuração__**:Utilize as reações para configurar.\n\n<a:numero_1:796978466619916298> **|** Prefixo: (\`$getServerVar[prefix]\`)\n<a:numero_2:796978493119660043> **|** Autorole: (<@&$getServerVar[autorole]>)\n<a:numero_3:796978528776093726> **|** Welcome: (<#$getServerVar[welcome]>)\n<a:numero_4:796978551462166538> **|** Leave: (<#$getServerVar[leave]>)}{footer:$username:$authorAvatar}{color:#FEB1D5}{image:https://cdn.discordapp.com/attachments/813988792196137000/815673547073519626/auroraconfiguracao.jpg}]
$setServerVar[welcome;$mentionedChannels[1]]

$onlyIf[$message[1]!=cancelar;Configuração cancelada. {deletecommand}{delete:10s}]

$onlyIf[$mentionedChannels[1]!=;**Mencione um canal válido deste servidor, como por exemplo:**
<#$channelID> {deletecommand}{delete:10s}]
$suppressErrors[]`
}