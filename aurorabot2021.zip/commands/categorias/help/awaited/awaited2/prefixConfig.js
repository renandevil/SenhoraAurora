module.exports.awaitedCommand = {
name: "prefixConfig",
code: `$awaitMessages[$authorID;20s;everything;prefixConfig2;]
$sendMessage[🤔 Digite o prefixo que voçê deseja ou \`cancelar\` para cancelar a configuração.;no]
$setUserVar[prefixConfig;$message[1]]
$clearReactions[$channelID;$message[1];all]
$suppressErrors[]
$onlyPerms[manageserver;{description: **<:alerta:779959668167802910> você precisa da permissão de \`gerenciar servidor\` para poder utilizar este comando!**}{color: FEB1D5} {deletecommand} {delete:10s}]`
}