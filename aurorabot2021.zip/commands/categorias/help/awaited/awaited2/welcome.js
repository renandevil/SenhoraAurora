module.exports.awaitedCommand = {
name: "welcome",
code: `$awaitMessages[$authorID;20s;everything;welcome2;]
$sendMessage[🤔 Mencione o canal que você deseja para setar o canal de welcome
\`(imagem de boas-vindas)\`

-> Caso queire **cancelar** esta configuração, digite \`cancelar\`
-> Para **desativar** o welcome, digite \`$getServerVar[prefix]desativar welcome\`;no]
$deleteIn[20s]
$setUserVar[welcome;$message[1]]
$clearReactions[$channelID;$message[1];all]
$suppressErrors[]
$onlyPerms[manageserver;{description: **<:alerta:779959668167802910> você precisa da permissão de \`gerenciar servidor\` para poder utilizar este comando!**}{color: FEB1D5} {deletecommand} {delete:10s}]`
}