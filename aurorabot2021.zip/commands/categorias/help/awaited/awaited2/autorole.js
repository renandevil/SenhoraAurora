module.exports.awaitedCommand = {
name: "autorole",
code: `$awaitMessages[$authorID;20s;everything;autorole2;]
$sendMessage[🤔 Mencione o cargo que você deseja para setar o cargo de autorole
\`(cargo que a pessoa irá ganhar automaticamente ao entrar no servidor)\`

-> Caso queire **cancelar** esta configuração, digite \`cancelar\`
-> Para **desativar** o autorole, digite \`$getServerVar[prefix]desativar autorole\`;no]
$deleteIn[20s]
$setUserVar[autorole;$message[1]]
$clearReactions[$channelID;$message[1];all]
$suppressErrors[]
$onlyPerms[manageserver;{description: **<:alerta:779959668167802910> você precisa da permissão de \`gerenciar servidor\` para poder utilizar este comando!**}{color: FEB1D5} {deletecommand} {delete:10s}]`
}