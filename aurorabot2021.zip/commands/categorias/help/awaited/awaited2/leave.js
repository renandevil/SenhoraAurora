module.exports.awaitedCommand = {
name: "leave",
code: `$awaitMessages[$authorID;20s;everything;leave2;]
$sendMessage[🤔 Mencione o canal que você deseja para setar o canal de leave
\`(imagem de adeus)\`

-> Caso queire **cancelar** esta configuração, digite \`cancelar\`
-> Para **desativar** o leave, digite \`$getServerVar[prefix]desativar leave\`;no]
$deleteIn[20s]
$setUserVar[leave;$message[1]]
$clearReactions[$channelID;$message[1];all]
$suppressErrors[]
$onlyPerms[manageserver;{description: **<:alerta:779959668167802910> você precisa da permissão de \`gerenciar servidor\` para poder utilizar este comando!**}{color: FEB1D5} {deletecommand} {delete:10s}]`
}