module.exports.awaitedCommand = {
name: "msc",
code: `$editMessage[$message[1];<@$authorID>{title:<:auroratm:845422854065618954> - Painel de ajuda - $username[$clientID]}{field:Anúncios:$getVar[ads]}{field:Links:[Me convide](https://discord.com/oauth2/authorize?client_id=773784582855720961&scope=bot+applications.commands&permissions=37013568) | [Vote em mim](https://top.gg/bot/773784582855720961/vote) | [Servidor de Suporte](https://discord.gg/vXvMU3Wcwq)}{field:🎵 **Comandos de música**:
\`$getServerVar[prefix]play\` - Ouça músicas no chat de voz.
\`$getServerVar[prefix]gender\` - Ouça playlists prontas de um gênero específico.
\`$getServerVar[prefix]queue\` - Veja todas as músicas na fila.
\`$getServerVar[prefix]skip\` - Pula a música atual.
\`$getServerVar[prefix]jump\` - Pula todas as músicas até a que você quer.
\`$getServerVar[prefix]loop\` - Repita a música atual.
\`$getServerVar[prefix]lyrics\` - Pesquise letras de músicas.
\`$getServerVar[prefix]speed\` - Deixe a música mais rápida.
\`$getServerVar[prefix]volume\` - Ajuste o volume das músicas.
\`$getServerVar[prefix]nowplaying\` - Veja informações da música atual e quanto tempo falta para acabar.
\`$getServerVar[prefix]pause\` - Pause a música atual.
\`$getServerVar[prefix]resume\` - Despause a música atual.
\`$getServerVar[prefix]stop\` - Para de tocar as músicas e limpa a fila inteira.
\`$getServerVar[prefix]leave\` - Faz a Aurora™ sair do canal de voz.\n}{image:https://cdn.discordapp.com/attachments/829829138185060352/854169242529824778/PicsArt_06-14-10.16.09.jpg}{footer:
$username:$authorAvatar}{color:#FEB1D5}]`
}