module.exports.command = {
	name: "help", aliases: ['ajuda', "comandos", "commands"],
	code: `
	$reactionCollector[$splitText[1];$authorID;1m;<a:numero_1:796978466619916298>,<a:numero_2:796978493119660043>,<a:numero_3:796978528776093726>,<a:numero_4:796978551462166538>,<a:numero_5:796978573365870602>,<a:numero_6:796978597075746846>,<:senhora_seta_voltar:797141464999002152>;adm,utl,div,eco,msc,con,menu;no]
	$textSplit[$sendMessage[<@$authorID>{title:<:auroratm:845422854065618954> | Painel de Ajuda - $username[$clientID]}{field:Anúncios:$getVar[ads]:yes}{field:Links:[Me convide](https://discord.com/oauth2/authorize?client_id=773784582855720961&scope=bot+applications.commands&permissions=37013568) | [Vote em mim](https://top.gg/bot/773784582855720961/vote) | [Servidor de Suporte](https://discord.gg/vXvMU3Wcwq):yes}{field:**Categorias**:<a:numero_1:796978466619916298> **|** \`Administração\`\n<a:numero_2:796978493119660043> **|** \`Utilitários\`\n<a:numero_3:796978528776093726> **|** \`Diversão\`\n<a:numero_4:796978551462166538> **|** \`Economia\`\n<a:numero_5:796978573365870602> **|** \`Música\`\n<a:numero_6:796978597075746846> **|** \`Configuração\`\n<:senhora_seta_voltar:797141464999002152> **|** \`Volta para esta tela\`:yes}{image:https://cdn.discordapp.com/attachments/829829138185060352/854168083945357392/PicsArt_06-14-10.09.09.jpg}{footer:$username:$authorAvatar}{color:#FEB1D5};yes]; ]
	$onlyBotPerms[embedlinks;Eu preciso da permissão de \`EMBED_LINKS\` para poder utilizar este comando!]
  $deletecommand
	$suppressErrors[Eita, algo deu errado, verifique se eu tenho algumas permissões básicas :/
	tipo "\`enviar links\`, \`enviar menssagens\` e \`usar emojis externos\`"]
	
	$cooldown[15s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:15s} {deletecommand}]
	
	$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]`
}