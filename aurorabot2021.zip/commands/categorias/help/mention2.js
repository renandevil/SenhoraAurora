module.exports.command = {
name: "<@!773784582855720961>",
nonPrefixed: true,
code: `$description[🌺 Olá <@$authorID>, sou uma bot multifuncional com comandos de administração, utilitários, diversão, economia, música e muito configurável!]

$addField[💫 Informações Rápidas;
- Prefixo neste Servidor: **\`$getServerVar[prefix]\`**
- Veje meus comandos utilizando **\`$getServerVar[prefix]help\`**

**[Me convide](https://discord.com/oauth2/authorize?client_id=773784582855720961&scope=bot+applications.commands&permissions=37013568) | [Vote em mim](https://top.gg/bot/773784582855720961/vote) | [Servidor de Suporte](https://discord.gg/vXvMU3Wcwq)**]
$color[#FEB1D5]

`
}