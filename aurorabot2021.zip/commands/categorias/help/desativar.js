  module.exports.command = {
  name: "desativar", aliases: "desativa",
  code: `$if[$checkcontains[$message;autorole]==true]
  
  ✅ <@$authorID> **Autorole desativado com sucesso!**

$setServerVar[autorole;Desativado] 
$deletecommand
  $endif
  
  $if[$checkcontains[$message;welcome]==true]
  
  ✅ <@$authorID> **Welcome desativado com sucesso!**

$setServerVar[welcome;Desativado]
$deletecommand
  $endif
  
$if[$checkcontains[$message;leave]==true]
  
  ✅ <@$authorID> **Leave desativado com sucesso!**

$setServerVar[leave;Desativado]
$deletecommand
  $endif
 `
  }