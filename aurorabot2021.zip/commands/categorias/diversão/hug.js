module.exports.command = {
name: "hug", aliases: ["abraço", "abraçar"],
code: `$reactionCollector[$splitText[1];$findUser[$message;no];40s;💞;hug2;no]
$textSplit[$sendMessage[<@$authorID>{description:**💞 <@$authorID> Abraçou <@$findUser[$message;no]>**}{image:$randomText[https://i.imgur.com/r9aU2xv.gif;https://i.imgur.com/wOmoeF8.gif;https://i.imgur.com/nrdYNtL.gif;https://i.imgur.com/v47M1S4.gif;https://i.imgur.com/82xVqUg.gif;https://i.imgur.com/4oLIrwj.gif;https://i.imgur.com/6qYOUQF.gif;https://i.imgur.com/UMm95sV.gif;]}{color:#FEB1D5}{footer:Reaja 💞 para retribuir!};yes]; ]
$setUserVar[slap;$authorID;$findUser[$message;no]]

$onlyIf[$mentioned[1]!=;{description: Você precisa mencionar alguém para dar um abraço}{color: FEB1D5} {deletecommand} {delete:5s}]

$cooldown[5s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:5s} {deletecommand}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]`
}