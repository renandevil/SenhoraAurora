module.exports.command = {
name: "kiss", aliases: ["beijar", "beijo"],
code: `$reactionCollector[$splitText[1];$findUser[$message;no];40s;😚;kiss2;no]
$textSplit[$sendMessage[<@$authorID>{description:**💏 <@$authorID> Beijou <@$findUser[$message;no]>**}{image:$randomText[https://i.imgur.com/sGVgr74.gif;https://i.imgur.com/YbNv10F.gif,https://i.imgur.com/TItLfqh.gif;https://i.imgur.com/wQjUdnZ.gif;https://i.imgur.com/KLVAl0T.gif;https://i.imgur.com/IgGumrf.gif;https://i.imgur.com/KKAMPju.gif;https://i.imgur.com/eisk88U.gif;https://i.imgur.com/9y34cfo.gif;https://i.imgur.com/MVS1ilF.gif;https://i.imgur.com/NkfsJV7.gif;https://i.imgur.com/COdNBUD.gif;https://i.imgur.com/PxzmuSj.gif]}{color:#FEB1D5}{footer:Reaja 😚 para retribuir!};yes]; ]
$setUserVar[kiss;$authorID;$findUser[$message;no]]

$onlyIf[$mentioned[1]!=;{description: Você precisa mencionar alguém para beijar}{color: FEB1D5} {deletecommand} {delete:5s}]

$cooldown[5s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:5s} {deletecommand}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]`
}