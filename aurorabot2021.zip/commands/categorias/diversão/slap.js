module.exports.command = {
name: "slap", aliases: ["tapa", "bater"],
code: `$reactionCollector[$splitText[1];$findUser[$message;no];40s;👋;slap2;no]
$textSplit[$sendMessage[<@$authorID>{description:**😾 <@$authorID> deu um tapa em <@$findUser[$message;no]>**}{image:$randomText[https://i.imgur.com/fm49srQ.gif;https://i.imgur.com/4MQkDKm.gif;https://i.imgur.com/o2SJYUS.gif;https://i.imgur.com/oOCq3Bt.gif;https://i.imgur.com/Agwwaj6.gif;https://i.imgur.com/mIg8erJ.gif;https://i.imgur.com/oRsaSyU.gif;https://i.imgur.com/kSLODXO.gif;https://i.imgur.com/CwbYjBX.gif;]}{color:#FEB1D5}{footer:Reaja 👋 para retribuir!};yes]; ]
$setUserVar[slap;$authorID;$findUser[$message;no]]

$onlyIf[$mentioned[1]!=;{description: Você precisa mencionar alguém para dar um tapa}{color: FEB1D5} {deletecommand} {delete:5s}]

$cooldown[5s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:5s} {deletecommand}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]`
}