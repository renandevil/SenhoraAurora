module.exports.command = {
 name: "dado", aliases: "dados",
 code: `$botTyping
 $deletecommand
 <a:dado:846822654983929866>
 $editIn[1s;<a:dado:846822654983929866>;🎲 Uhuull <@$authorID>, Girei o dado e parou em: \`$randomText[1️⃣;2️⃣;3️⃣;4️⃣;5️⃣;6️⃣]\`
 $cooldown[8s;Espera né, to pegando o dado q caiu no chão {deletecommand} {delete:8s}]
`
}