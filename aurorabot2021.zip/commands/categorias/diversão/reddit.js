module.exports.command = {
name: "meme", aliases: ["memes", "reddit"],
code: `$author[u/$jsonRequest[https://meme-api.herokuapp.com/gimme/$replaceText[$replaceText[€$message[1]€;€€;cellbits];€;];author] - r/$jsonRequest[https://meme-api.herokuapp.com/gimme/$replaceText[$replaceText[€$message[1]€;€€;cellbits];€;];subreddit];https://cdn.discordapp.com/emojis/819677855143165963.png?size=2048;$jsonRequest[https://meme-api.herokuapp.com/gimme/$replaceText[$replaceText[€$message[1]€;€€;cellbits];€;];
postLink]]
$title[$jsonRequest[https://meme-api.herokuapp.com/gimme/$replaceText[$replaceText[€$message[1]€;€€;cellbits];€;];title]]
$image[$jsonRequest[https://meme-api.herokuapp.com/gimme/$replaceText[$replaceText[€$message[1]€;€€;cellbits];€;];url]?size=2048]
$footer[$jsonRequest[https://meme-api.herokuapp.com/gimme/$replaceText[$replaceText[€$message[1]€;€€;cellbits];€;];ups];https://cdn.discordapp.com/emojis/819687787296063519.png?size=2048]
$color[FF4500]
$deletecommand

$cooldown[5s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:5s} {deletecommand}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]

$onlyNSFW[<@$authorID> Este comando só pode ser utilizado em canais com Conteúdo Adulto ativo, para a maior segurança. {deletecommand} {delete:10s}]

$setVar[comandos;$sum[$getVar[comandos];1]]`
}