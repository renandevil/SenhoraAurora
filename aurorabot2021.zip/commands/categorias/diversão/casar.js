module.exports.command = {
name: "casar",
code: `<@$get[user]>, <@$authorID> quer se casar com você, para que o casamento possa ser efetuado, você e ele(a) devem reagir com 💍

$addReactions[💍]

$onlyIf[$get[exists]==true;Como que o usuário \`\`\`$username[$findUser[$message]]\`\`\` vai se casar com você sendo que ele não está no servidor, logo não vai poder clicar na reação? :<]
$onlyIf[$get[user]!=$authorID;Você não pode casar com você mesmo!]

$let[exists;$memberExists[$get[user]]]
$let[user;$findUser[$message;no]]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]`
}