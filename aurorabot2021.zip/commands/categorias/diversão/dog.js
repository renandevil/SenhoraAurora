module.exports.command = {
name: "dog", aliases: ["cachorro"],
code: `$editMessage[$splitText[1];Imagem encontrada!{title:🐶 Auau}{image:$jsonRequest[https://api.toxy.ga/api/dog;url]}{footer:$username:$userAvatar[$authorID]}{color:$replaceText[$getRoleColor[$highestRole[$clientID]];000000;FEB1D5]}]

$textSplit[$sendMessage[Procurando imagem...;yes]; ]

$cooldown[5s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:5s} {deletecommand}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]
`
}