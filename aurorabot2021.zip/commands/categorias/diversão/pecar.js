module.exports.command = {
  name: "pecar",
  code: `
<@$authorID>
  $description[<:pepecruz:845385786299646012> Ei? <@$authorID> ta doido? vamo pra igreja orar imediatamente!]
  $color[FEB1D5]
  
  $cooldown[8s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:10s} {deletecommand}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]`
}