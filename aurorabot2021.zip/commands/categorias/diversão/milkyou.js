module.exports.command = {
name: "milkyou", aliases: "milk",
code: `$deletecommand

$image[https://dinosaur.ml/overlay/milkyou/?image2=$userAvatar[$mentioned[1;yes]]?image=$authorAvatar]
$title[Milk you rs]
$color[#FEB1D5]
$footer[$username;$authorAvatar]

$cooldown[5s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:5s} {deletecommand}]

$onlyIf[$mentioned[1]!=;Você precisa mencionar 1 usuário válido!{$deletecommand}{delete:5s}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]
  
$setVar[comandos;$sum[$getVar[comandos];1]]`
}