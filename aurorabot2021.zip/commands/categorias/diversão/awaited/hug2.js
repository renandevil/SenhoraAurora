module.exports.awaitedCommand = {
name: "hug2",
code: `$sendMessage[<@$authorID>{description:**💞 <@$authorID> Abraçou <@$getUserVar[hug]>**}{image:$randomText[https://i.imgur.com/r9aU2xv.gifv;https://i.imgur.com/wOmoeF8.gif;https://i.imgur.com/nrdYNtL.gif;https://i.imgur.com/v47M1S4.gif;https://i.imgur.com/82xVqUg.gif;https://i.imgur.com/4oLIrwj.gif;https://i.imgur.com/6qYOUQF.gif;https://i.imgur.com/UMm95sV.gif;]}{color:#FEB1D5}{footer:$userTag retribuiu o abraço 💞!};no]
$clearReactions[$channelID;$message[1];all]
`
}