module.exports.awaitedCommand = {
name: "slap2",
code: `$sendMessage[<@$authorID>{description:**😾 <@$authorID> deu um tapa em <@$getUserVar[slap]>**}{image:$randomText[https://i.imgur.com/fm49srQ.gif;https://i.imgur.com/4MQkDKm.gif;https://i.imgur.com/o2SJYUS.gif;https://i.imgur.com/oOCq3Bt.gif;https://i.imgur.com/Agwwaj6.gif;https://i.imgur.com/mIg8erJ.gif;https://i.imgur.com/oRsaSyU.gif;https://i.imgur.com/kSLODXO.gif;https://i.imgur.com/CwbYjBX.gif;]}{color:#FEB1D5}{footer:$userTag retribuiu o tapa 👋!};no]
$clearReactions[$channelID;$message[1];all]
`
}