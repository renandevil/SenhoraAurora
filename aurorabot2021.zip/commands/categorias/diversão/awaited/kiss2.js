module.exports.awaitedCommand = {
name: "kiss2",
code: `$sendMessage[<@$authorID>{description:**💏 <@$authorID> Beijou <@$getUserVar[kiss]>**}{image:$randomText[https://i.imgur.com/sGVgr74.gif;https://i.imgur.com/YbNv10F.gif,https://i.imgur.com/TItLfqh.gif;https://i.imgur.com/wQjUdnZ.gif;https://i.imgur.com/KLVAl0T.gif;https://i.imgur.com/IgGumrf.gif;https://i.imgur.com/KKAMPju.gif;https://i.imgur.com/eisk88U.gif;https://i.imgur.com/9y34cfo.gif;https://i.imgur.com/MVS1ilF.gif;https://i.imgur.com/NkfsJV7.gif;https://i.imgur.com/COdNBUD.gif;https://i.imgur.com/PxzmuSj.gif]}{color:#FEB1D5}{footer:$userTag retribuiu o beijo 😚!};no]
$clearReactions[$channelID;$message[1];all]
`
}