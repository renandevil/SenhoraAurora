module.exports.command = {
name: "ascii",
code: `<@$authorID>
\`\`\`\n$jsonRequest[https://artii.herokuapp.com/make?text=$message]\n\`\`\`
$argsCheck[>1;**Use:**
\`$getServerVar[prefix]ascii Aurora\` {deletecommand} {delete:5s}]

$cooldown[5s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:5s} {deletecommand}]

  $onlyIf[$charCount[$message]<8;Você só pode utilizar este comando em até \`8\` caracteres, e a sua mensagem contém \`$charCount[$message]\` {deletecommand} {delete:10s}]

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]

$setVar[comandos;$sum[$getVar[comandos];1]]`
}