module.exports.command = {
 name: "set-leave", aliases: ["saida", "setleave"],
 code: `

$setServerVar[leave;$mentionedChannels[1]]

$description[✅ **Canal de leave setado com sucesso!**

**Canal setado:**
$mentionedChannels[1]
]
$color[$getVar[color]]

$cooldown[15s;<@$authorID> Espere 15 segundos para a configuração desta função novamente. {deletecommand} {delete:8s}]

$onlyPerms[manageserver;{description: Você não tem a permissão de \`Gerenciar Servidor\` para utilizar este comando.}{color:$getVar[color]}]
$suppressErrors[]

$onlyIf[$mentionedChannels[1]!=;{description:**Mencione um canal de texto válido deste servidor para as menssagens de saída de membros serem enviadas, como por exemplo:**
\`$getServerVar[prefix]set-leave\` <#$channelID>}{delete:10s}]

`
}