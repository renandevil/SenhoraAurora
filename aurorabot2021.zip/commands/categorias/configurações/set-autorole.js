  module.exports.command = {
  name: "set-autorole", aliases: ["setautorole", "autorole"],
  code: `$if[$getServerVar[lang]==pt-br]
  
 ✅ <@$authorID> **Autorole configurado para \`$message[1]\`!**

$setServerVar[autorole;$mentionedRoles[1]]

  $endif
  
  
  $if[$getServerVar[lang]==en]
  
✅ <@$authorID> **Autorole configured for \`$message[1]\`!**

$setServerVar[autorole;$mentionedRoles[1]]

  $endif
  
$cooldown[15s;<@$authorID> Espere 20 segundos para a configuração desta função novamente. {deletecommand} {delete:8s}]
  
$argsCheck[>1;{description:❌ **Use o comando de forma correta!**

- **Como utilizar:**
\`$getServerVar[prefix]set-autorole <cargo>\`
- **Exemplos:**
\`$getServerVar[prefix]set-autorole @cargo\`
\`$getServerVar[prefix]set-autorole @membros\`}
{color:$getVar[color]}]
  
$onlyPerms[manageserver;{description: Você não tem a permissão de \`Gerenciar Servidor\` para utilizar este comando.}{color:$getVar[color]}]
$suppressErrors[]

$onlyIf[$mentionedRoles[1]!=;**Mencione um cargo válido deste servidor** {deletecommand}{delete:10s}]
`
}