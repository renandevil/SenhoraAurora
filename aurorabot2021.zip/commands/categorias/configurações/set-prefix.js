  module.exports.command = {
  name: "set-prefix", aliases: ["setprefix", "prefixo", "prefix", "server-prefix"],
  code: `$if[$getServerVar[lang]==pt-br]
  
 ✅ <@$authorID> **O prefixo da bot foi configurado para \`$message[1]\`!**

$setServerVar[prefix;$message[1]]

  $endif
  
  
  $if[$getServerVar[lang]==en]
  
✅ <@$authorID> ** The bot prefix has been set to \`$message[1]\`!**

$setServerVar[prefix;$message[1]]

  $endif
  
$cooldown[15s;<@$authorID> Espere 15 segundos para a configuração desta função novamente. {deletecommand} {delete:8s}]
  
$argsCheck[>1;{description:❌ **Use o comando de forma correta!**

- **Como utilizar:**
\`$getServerVar[prefix]set-prefix <novo prefixo>\`
- **Exemplos:**
\`$getServerVar[prefix]set-prefix -\`
\`$getServerVar[prefix]set-prefix a!\`}
{color:$getVar[color]}]

$onlyIf[$charCount[$message]<10; Você precisa escrever um prefixo com menos de 10 letras, e seu prefixo contém \`$charCount[$message]\`]
  
$onlyPerms[manageserver;{description: Você não tem a permissão de \`Gerenciar Servidor\` para utilizar este comando.}{color:$getVar[color]}]
$suppressErrors[]
`
}