const duration = `$replaceText[$replaceText[$splitText[1];(;];);] $textSplit[$songInfo[duration]; ]`
const current = `$replaceText[$replaceText[$splitText[1];(;];);] $textSplit[$songInfo[current_duration]; ]`
const duration1 = `$jsonrequest[https://api.itzteduhyt.repl.co/progressbar?now=1?max=$advancedtextsplit[$songinfo[duration]; ;1];timestamp]`
const current1 = `$replaceText[$replaceText[$splitText[3];(;];);]$textSplit[$songInfo[current_duration]; ]`

module.exports.command = {
 name: "nowplaying", aliases: ["np", "tocando"],
 code: `
 
$if[$getServerVar[lang]==pt-br]
<@$authorID>
$title[$songInfo[title];$songInfo[url]]
$description[$getObjectProperty[bar]

\`${current1} / $advancedtextsplit[${duration1};/;2]\`

Pedido por <@$songInfo[userID]>]
$color[$getVar[color]]
$author[Tocando Agora;$userAvatar[$clientID]]
$djseval[const util = require('dbd.js-utils')
d.object.bar = util.progressBar(${current}, ${duration}, 20, "💿", "▬", "▬")]
$createObject[{}]

$onlyIf[$queueLength!=0;{description: Não há músicas tocando para isso, adicione uma usando \`$getServerVar[prefix]play\`}{color:$getVar[color]}]
$endif

$if[$getServerVar[lang]==en]
<@$authorID>
$title[$songInfo[title];$songInfo[url]]
$description[$getObjectProperty[bar]

\`${current1} / $advancedtextsplit[${duration1};/;2]\`

Order by <@$songInfo[userID]>]
$color[$getVar[color]]
$author[Playing now;$userAvatar[$clientID]]
$djseval[const util = require('dbd.js-utils')
d.object.bar = util.progressBar(${current}, ${duration}, 20, "💿", "▬", "▬")]
$createObject[{}]

$onlyIf[$queueLength!=0;{description: There are no songs playing for this, add one using \`$getServerVar[prefix]play\`}{color:$getVar[color]}]
$endif

$cooldown[5s;<@$authorID> Você está usando meus comandos muito rápido! $randomText[-_-;OwO;U.u;:<;:0;'_']]

`
}