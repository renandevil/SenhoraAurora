module.exports.command = {
 name: "leave",
 aliases: ["disconnect", "dc", "sair"],
 code: `
 $if[$getServerVar[lang]==pt-br]
<@$authorID>
$description[🌺 Acabei de sair do canal de voz <#$voiceid[$clientid]>, espero que tenha gostado das músicas!]
$color[$getVar[color]]
$leavevc

$onlyif[$voiceid[$clientid]!=;Eu não estou conectada em um canal de voz]

$onlyIf[$voiceid[$authorid]!=;Entre no meu canal de voz para efetuar esta ação]
$endif

$if[$getServerVar[lang]==en]
<@$authorID>
$description[🌺 I just left the voice channel <#$voiceid[$clientid]>, I hope you enjoyed the songs!]
$color[$getVar[color]]
$leavevc

$onlyif[$voiceid[$clientid]!=;I'm not connected to a voice channel]

$onlyIf[$voiceid[$authorid]!=;Enter my voice channel to perform this action]
$endif
`
}