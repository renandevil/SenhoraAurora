module.exports.command = {
 name: "speed", aliases: "velocidade",
 code: `$addCmdReactions[⏩]
$songFilter[speed:$message[1]]

$onlyIf[$message[1]<2;O limite da velocidade é 1.9 {deletecommand} {delete:10s}]
$onlyIf[$message[1]>0.1;O Mínimo da velocidade é 0.2 {deletecommand} {delete:10s}]
 $onlyIf[$isNumber[$message[1]]==true]
 $argsCheck[>1;**Use:** \`$getServerVar[prefix]speed <0.2 - 1.9>\` (1.0 é a velocidade padrão){deletecommand} {delete:10s}]
 
$onlyIf[$queueLength!=0;{description: Não ah músicas tocando para isto, adicione uma utilizando \`$getServerVar[prefix]play\`}{deletecommand}{delete:10s}{color:FEB1D5}]
 $onlyif[$voiceid[$authorid]==$voiceid[$clientid];{description: Você não está no mesmo canal de voz que eu!}{color:FEB1D5}{deletecommand}{delete:10s}]
 $onlyIf[$voiceID!=;{description: **Você não está conectado a um canal de voz!**}{color: FEB1D5} {deletecommand} {delete:10s}]
 
 $cooldown[5s;<@$authorID> Você está usando meus comandos muito rápido! $randomText[-_-;OwO;U.u;:<;:0;'_']]
 
 $channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]` 
}