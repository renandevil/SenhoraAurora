module.exports.command = {
 name: "skipto", aliases: ['jump'],
 code:`$deletecommand
 
 $color[FEB1D5]
 $author[$userTag[$authorID];$authorAvatar]
 $title[Pulado para $message[1]]
 $description[**Pronto!** pulei todas as músicas até a posição \`$message[1]\` do queue!]
 $footer[$username;$authorAvatar]
 $skipTo[$message[1]]
 
$onlyIf[$queueLength!=0;{description: Não ah músicas tocando para isto, adicione uma utilizando \`$getServerVar[prefix]play\`}{deletecommand}{delete:10s}{color:FEB1D5}]
	$onlyif[$voiceid[$authorid]==$voiceid[$clientid];{description: Você não está no mesmo canal de voz que eu!}{color:FEB1D5}{deletecommand}{delete:10s}]
$onlyIf[$voiceID!=;{description: **Você não está conectado a um canal de voz!**}{color: FEB1D5} {deletecommand} {delete:10s}]
$argsCheck[>1; Coloque o número da posição da música do queue que deseja tocar ela de imediato, sem precisar esperar,
**exemplo:** \`$getServerVar[prefix]jump 4\`{deletecommand}{delete:10s}]


 $channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]

$cooldown[5s;<@$authorID> Você está usando meus comandos muito rápido! $randomText[-_-;OwO;U.u;:<;:0;'_']]

 $onlyIf[$checkContains[$channelType;text;news]==true;]

 $suppressErrors[Algo deu erradu...{delete:10s}]
 `
}