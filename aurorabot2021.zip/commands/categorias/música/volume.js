module.exports.command = {
	name: "volume", aliases: ["vol", "som"],
code: `
$if[$getServerVar[lang]==pt-br]
	
$if[$checkContains[$message;baixo]==true]
<@$authorID>
$title[🔈 Configuração do Volume]
 $description[O volume mudou para **baixo**.]
$color[$getVar[color]]
$volume[20]
 $endif
 
$if[$checkContains[$message;médio]==true]
<@$authorID>
$title[🔉 Configuração do Volume]
 $description[O volume mudou para **médio**.]
$color[$getVar[color]]
$volume[100]
 $endif
 
$if[$checkContains[$message;alto]==true]
<@$authorID>
$title[🔊 Configuração do Volume]
 $description[O volume mudou para **alto**.]
$color[$getVar[color]]
$volume[200]
 $endif
 
 $argsCheck[>1;<@$authorID>{title: Configuração do Volume}
 {description:Configure o volume das músicas que o bot vai tocar.
🔨 **Variáveis:**
- \`$getServerVar[prefix]volume\` **baixo**
- \`$getServerVar[prefix]volume\` **médio**
- \`$getServerVar[prefix]volume\` **alto**
 }{color:$getVar[color]}]

$onlyIf[$queueLength!=0;{description: Não ah músicas tocando para isto, adicione uma utilizando \`$getServerVar[prefix]play\`}{color:$getVar[color]}]

$onlyif[$voiceid[$authorid]==$voiceid[$clientid];{description: Você não está no mesmo canal de voz que eu!}{color:$getVar[color]}]

$onlyIf[$voiceID!=;{description: **Você não está conectado a um canal de voz!**}{color: $getVar[color]}]
$endif

$if[$getServerVar[lang]==en]

$if[$checkContains[$message;low]==true]
<@$authorID>
$title[🔈 Volume Configuration]
 $description[Volume changed to **low**.]
$color[$getVar[color]]
$volume[20]
 $endif
 
$if[$checkContains[$message;average]==true]
<@$authorID>
$title[🔉 Volume Configuration]
 $description[Volume changed to **average**.]
$color[$getVar[color]]
$volume[100]
 $endif
 
$if[$checkContains[$message;high]==true]
<@$authorID>
$title[🔊 Volume Configuration]
 $description[Volume changed to **high**.]
$color[$getVar[color]]
$volume[200]
 $endif

 $argsCheck[>1;<@$authorID>{title: Volume Configuration}
 {description:Configure the volume of the songs that the bot will play.
🔨 **Variables:**
- \`$getServerVar[prefix]volume\` **low**
- \`$getServerVar[prefix]volume\` **average**
- \`$getServerVar[prefix]volume\` **high**
 }{color:$getVar[color]}]

$onlyIf[$queueLength!=0;{description: There are no songs playing for this, add one using \`$getServerVar[prefix]play\`}{color:$getVar[color]}]

$onlyif[$voiceid[$authorid]==$voiceid[$clientid];{description: You are not on the same voice channel as me!}{color:$getVar[color]}]

$onlyIf[$voiceID!=;{description: **You are not connected to a voice channel!**}{color: $getVar[color]}]
$endif


$onlyIf[$jsonRequest[https://top.gg/api/bots/$clientID/check?userId=$authorID;voted;error;Authorization:eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6Ijc3Mzc4NDU4Mjg1NTcyMDk2MSIsImJvdCI6dHJ1ZSwiaWF0IjoxNjIyNTIyNDExfQ.O-33wC3UJXKnf1wHTkum26HnG6SDLuGskJAz5hcY9I8]==1; <@$authorID> {description:-> Este comando requer que você vote em mim, e você ainda não votou em mim no Top.gg, [clicando aqui](https://top.gg/bot/773784582855720961/vote) você é direcionado para a aba de votar em mim

-> **Para receber recompensas a cada 12 horas por ter votado em mim, utilize o comando 
\`$getServerVar[prefix]verificar\` para verificar seu voto!**}{color:$getVar[color]}]

$if[$jsonRequest[https://top.gg/api/bots/$clientID/check?userId=$authorID;voted;error;Authorization:eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6Ijc3Mzc4NDU4Mjg1NTcyMDk2MSIsImJvdCI6dHJ1ZSwiaWF0IjoxNjIyNTIyNDExfQ.O-33wC3UJXKnf1wHTkum26HnG6SDLuGskJAz5hcY9I8]==1]
$addCmdReactions[✅]

$else

$endif

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]

$cooldown[5s;<@$authorID> Você está usando meus comandos muito rápido! $randomText[-_-;OwO;U.u;:<;:0;'_']]
`
}