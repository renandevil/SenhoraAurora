module.exports.command = {
	name: "loop", aliases: "repetir",
	code: `
	$if[$getServerVar[lang]==pt-br]
	<@$authorID>
	$description[🔂 Repetindo a música atual.]
	$color[$getVar[color]]
	$textSplit[$loopQueue; ]

$onlyIf[$queueLength!=0;{description: Não ah músicas tocando para isto, adicione uma utilizando \`$getServerVar[prefix]play\`}{color:$getVar[color]}]

$onlyif[$voiceid[$authorid]==$voiceid[$clientid];{description: Você não está no mesmo canal de voz que eu!}{color:$getVar[color]}]

$onlyIf[$voiceID!=;{description: **Você não está conectado a um canal de voz!**}{color: $getVar[color]}]
$endif

$if[$getServerVar[lang]==en]
	<@$authorID>
	$description[🔂 Repeating the current song.]
	$color[$getVar[color]]
	$textSplit[$loopQueue; ]

$onlyIf[$queueLength!=0;{description: There are no songs playing for this, add one using \`$getServerVar[prefix]play\`}{color:$getVar[color]}]

$onlyif[$voiceid[$authorid]==$voiceid[$clientid];{description: You are not on the same voice channel as me!}{color:$getVar[color]}]

$onlyIf[$voiceID!=;{description: **You are not connected to a voice channel!**}{color: $getVar[color]}]
$endif

$cooldown[5s;<@$authorID> Você está usando meus comandos muito rápido! $randomText[-_-;OwO;U.u;:<;:0;'_']]
`
}