module.exports.command = {
	name: "skip", aliases: ["s", "pular"],
	code: `

$if[$getServerVar[lang]==pt-br]

<@$authorID>
	$description[⏩ Música atual pulada.]
	$color[$getVar[color]]
	$skipSong
	
$onlyIf[$queueLength!=0;{description: Não há músicas tocando para isso, adicione uma usando \`$getServerVar[prefix]play\`}{color:$getVar[color]}]

	$onlyif[$voiceid[$authorid]==$voiceid[$clientid];{description: Você não está no mesmo canal de voz que eu!}{color:$getVar[color]}]
	
$onlyIf[$voiceID!=;{description: **Você não está conectado a um canal de voz!**}{color:$getVar[color]}]


$endif


$if[$getServerVar[lang]==en]

<@$authorID>
	$description[⏩ Current music skipped.]
	$color[$getVar[color]]
	$skipSong
	
$onlyIf[$queueLength!=0;{description: There are no songs playing for this, add one using \`$getServerVar[prefix]play\`}{color:$getVar[color]}]

	$onlyif[$voiceid[$authorid]==$voiceid[$clientid];{description: You are not on the same voice channel as me!}{color:$getVar[color]}]
	
$onlyIf[$voiceID!=;{description: **You are not connected to a voice channel!**}{color:$getVar[color]}]

$endif

$channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]

$cooldown[2s;<@$authorID> Você está utilizando meus comandos muito rápido! $randomText[-_-;OwO;U.u;:<;:0;'_']]
`

}