module.exports.command = {
 name: "gender", aliases: ["gênero", "genero"],
 code: `
$if[$getServerVar[lang]==pt-br]

$if[$checkContains[$message;pop]==true]
<@$authorID>
$title[<:music:847284580141498379> Gênero Musical]
 $description[Gênero **Pop** selecionado, aguarde enquanto eu monto sua lista  $playSpotify[https://open.spotify.com/playlist/37i9dQZF1DX6aTaZa0K6VA?si=3icCo6D9RA2FwXk7Tt928Q&utm_source=copy-link;name;yes;yes;{color:$getVar[color]}{title:Error}{description:Algo deu errado}{delete:5s}{deletecommand}]]
$color[$getVar[color]]
$onlyIf[$voiceID!=;{description: **Você não está conectado a um canal de voz!**} {color:$getVar[color]}]
 $endif
 
$if[$checkContains[$message;funk]==true]
<@$authorID>
$title[<:music:847284580141498379> Gênero Musical]
 $description[Gênero **Funk** selecionado, aguarde enquanto eu monto sua lista  $playSpotify[https://open.spotify.com/playlist/37i9dQZF1DWTkIwO2HDifB?si=6YpOumfISUiAeoXzLzg5XA&utm_source=copy-link;name;yes;yes;{color:$getVar[color]}{title:Error}{description:Algo deu errado}{delete:5s}{deletecommand}]]
$color[$getVar[color]]
$onlyIf[$voiceID!=;{description: **Você não está conectado a um canal de voz!**} {color:$getVar[color]}]
 $endif
 
 
$if[$checkContains[$message;lol]==true]
<@$authorID>
$title[<:music:847284580141498379> Gênero Musical]
 $description[Gênero **League of Legends** selecionado, aguarde enquanto eu monto sua lista  $playSpotify[https://open.spotify.com/playlist/37i9dQZF1DWVi45nh2EuPP?si=eRZVggjfQvSe9nc9c_0Qxg&utm_source=copy-link;name;yes;yes;{color:$getVar[color]}{title:Error}{description:Algo deu errado}{delete:5s}{deletecommand}]]
$color[$getVar[color]]
$onlyIf[$voiceID!=;{description: **Você não está conectado a um canal de voz!**} {color:$getVar[color]}]
 $endif
 
$if[$checkContains[$message;sertanejo]==true]
<@$authorID>
$title[<:music:847284580141498379> Gênero Musical]
 $description[Gênero **Sertanejo** selecionado, aguarde enquanto eu monto sua lista  $playSpotify[https://open.spotify.com/playlist/37i9dQZF1DXdSjVZQzv2tl?si=YcAYtx8MQtavRQXy65fAqw&utm_source=copy-link;name;yes;yes;{color:$getVar[color]}{title:Error}{description:Algo deu errado}{delete:5s}{deletecommand}]]
$color[$getVar[color]]
$onlyIf[$voiceID!=;{description: **Você não está conectado a um canal de voz!**} {color:$getVar[color]}]
 $endif
 
 $if[$checkContains[$message;anime]==true]
<@$authorID>
$title[<:music:847284580141498379> Gênero Musical]
 $description[Gênero **Anime** selecionado, aguarde enquanto eu monto sua lista  $playSpotify[https://open.spotify.com/playlist/37i9dQZF1DWT8aqnwgRt92?si=AnCJOB18TL6MX9LJLhMBUA&utm_source=copy-link;name;yes;yes;{color:$getVar[color]}{title:Error}{description:Algo deu errado}{delete:5s}{deletecommand}]]
$color[$getVar[color]]
$onlyIf[$voiceID!=;{description: **Você não está conectado a um canal de voz!**} {color:$getVar[color]}]
 $endif
 
 $if[$checkContains[$message;kpop]==true]
<@$authorID>
$title[<:music:847284580141498379> Gênero Musical]
 $description[Gênero **Kpop** selecionado, aguarde enquanto eu monto sua lista  $playSpotify[https://open.spotify.com/playlist/37i9dQZF1DX9tPFwDMOaN1?si=d_Hhn_ghSUWqCHZd507DdQ&utm_source=copy-link;name;yes;yes;{color:$getVar[color]}{title:Error}{description:Algo deu errado}{delete:5s}{deletecommand}]]
$color[$getVar[color]]
$onlyIf[$voiceID!=;{description: **Você não está conectado a um canal de voz!**} {color:$getVar[color]}]
 $endif

 $if[$checkContains[$message;lofi]==true]
<@$authorID>
$title[<:music:847284580141498379> Gênero Musical]
 $description[Gênero **Lofi** selecionado, aguarde enquanto eu monto sua lista  $playSpotify[https://open.spotify.com/playlist/37i9dQZF1DWWQRwui0ExPn?si=O4P9ZMC_RGyjVoHfq5IUUg&utm_source=copy-link;name;yes;yes;{color:$getVar[color]}{title:Error}{description:Algo deu errado}{delete:5s}{deletecommand}]]
$color[$getVar[color]]
$onlyIf[$voiceID!=;{description: **Você não está conectado a um canal de voz!**} {color:$getVar[color]}]
 $endif

 $if[$checkContains[$message;rock]==true]
<@$authorID>
$title[<:music:847284580141498379> Gênero Musical]
 $description[Gênero **Rock** selecionado, aguarde enquanto eu monto sua lista  $playSpotify[https://open.spotify.com/playlist/37i9dQZF1DX4908CEYEdlz?si=d0ut6a3WS8esYpVHqL62NQ&utm_source=copy-link;name;yes;yes;{color:$getVar[color]}{title:Error}{description:Algo deu errado}{delete:5s}{deletecommand}]]
$color[$getVar[color]]
$onlyIf[$voiceID!=;{description: **Você não está conectado a um canal de voz!**} {color:$getVar[color]}]
 $endif

 $if[$checkContains[$message;kids]==true]
<@$authorID>
$title[<:music:847284580141498379> Gênero Musical]
 $description[Gênero **Kids** selecionado, aguarde enquanto eu monto sua lista  $playSpotify[https://open.spotify.com/playlist/37i9dQZF1DXbnTV8GtwMLQ?si=zL7uCoCRT-SVn75eUWuoBQ&utm_source=copy-link;name;yes;yes;{color:$getVar[color]}{title:Error}{description:Algo deu errado}{delete:5s}{deletecommand}]]
$color[$getVar[color]]
$onlyIf[$voiceID!=;{description: **Você não está conectado a um canal de voz!**} {color:$getVar[color]}]
 $endif

 $if[$checkContains[$message;hits]==true]
<@$authorID>
$title[<:music:847284580141498379> Gênero Musical]
 $description[Gênero **Hits** selecionado, aguarde enquanto eu monto sua lista  $playSpotify[https://open.spotify.com/playlist/37i9dQZEVXbMDoHDwVN2tF?si=grZNfzA1Rg-bVXjJST1PRQ&utm_source=copy-link;name;yes;yes;{color:$getVar[color]}{title:Error}{description:Algo deu errado}{delete:5s}{deletecommand}]]
$color[$getVar[color]]
$onlyIf[$voiceID!=;{description: **Você não está conectado a um canal de voz!**} {color:$getVar[color]}]
 $endif
 
 $argsCheck[>1;<@$authorID>{title:Gêneros musicais}
 {description:Selecione o gênero de música que você deseja para eu montar uma lista apenas com o gênero selecionado.
🎵 **Gêneros Disponíveis:**
- \`$getServerVar[prefix]gender\` **pop**
- \`$getServerVar[prefix]gender\` **funk**
- \`$getServerVar[prefix]gender\` **lol**
- \`$getServerVar[prefix]gender\` **sertanejo**
- \`$getServerVar[prefix]gender\` **anime**
- \`$getServerVar[prefix]gender\` **kpop**
- \`$getServerVar[prefix]gender\` **lofi**
- \`$getServerVar[prefix]gender\` **rock**
- \`$getServerVar[prefix]gender\` **kids**
- \`$getServerVar[prefix]gender\` **hits**
 }{color:$getVar[color]}]
 $endif
 
$if[$getServerVar[lang]==en]

$if[$checkContains[$message;pop]==true]
 <@$authorID>
 $title[<:music:847284580141498379> Musical Genre]
 $description[Selected **Pop** Genre, wait while I build your list  $playSpotify[https://open.spotify.com/playlist/37i9dQZF1DX6aTaZa0K6VA?si=3icCo6D9RA2FwXk7Tt928Q&utm_source=copy-link;name;yes;yes;{color:$getVar[color]}{title:Error}{description:Something went wrong}{delete:5s}{deletecommand}]]
 $color[$getVar[color]]
 $onlyIf[$voiceID!=;{description: **You are not connected to a voice channel!**} {color:$getVar[color]}]
 $endif
 
$if[$checkContains[$message;funk]==true]
 <@$authorID>
 $title[<:music:847284580141498379> Musical Genre]
 $description[Selected **Funk** Genre, wait while I build your list  $playSpotify[https://open.spotify.com/playlist/37i9dQZF1DWTkIwO2HDifB?si=6YpOumfISUiAeoXzLzg5XA&utm_source=copy-link;name;yes;yes;{color:$getVar[color]}{title:Error}{description:Something went wrong}{delete:5s}{deletecommand}]]
 $color[$getVar[color]]
 $onlyIf[$voiceID!=;{description: **You are not connected to a voice channel!**} {color:$getVar[color]}]
 $endif
 
$if[$checkContains[$message;lol]==true]
 <@$authorID>
 $title[<:music:847284580141498379> Musical Genre]
 $description[Selected **League of Legends** Genre, wait while I build your list  $playSpotify[https://open.spotify.com/playlist/37i9dQZF1DWVi45nh2EuPP?si=eRZVggjfQvSe9nc9c_0Qxg&utm_source=copy-link;name;yes;yes;{color:$getVar[color]}{title:Error}{description:Something went wrong}{delete:5s}{deletecommand}]]
 $color[$getVar[color]]
 $onlyIf[$voiceID!=;{description: **You are not connected to a voice channel!**} {color:$getVar[color]}]
 $endif
 
$if[$checkContains[$message;sertanejo]==true]
<@$authorID>
 $title[<:music:847284580141498379> Musical Genre]
 $description[Selected **Sertanejo** Genre, wait while I build your list  $playSpotify[https://open.spotify.com/playlist/37i9dQZF1DXdSjVZQzv2tl?si=YcAYtx8MQtavRQXy65fAqw&utm_source=copy-link;name;yes;yes;{color:$getVar[color]}{title:Error}{description:Something went wrong}{delete:5s}{deletecommand}]]
 $color[$getVar[color]]
 $onlyIf[$voiceID!=;{description: **You are not connected to a voice channel!**} {color:$getVar[color]}]
 $endif
 
$if[$checkContains[$message;anime]==true]
 <@$authorID>
 $title[<:music:847284580141498379> Musical Genre]
 $description[Selected **Anime** Genre, wait while I build your list  $playSpotify[https://open.spotify.com/playlist/37i9dQZF1DWT8aqnwgRt92?si=AnCJOB18TL6MX9LJLhMBUA&utm_source=copy-link;name;yes;yes;{color:$getVar[color]}{title:Error}{description:Something went wrong}{delete:5s}{deletecommand}]]
 $color[$getVar[color]]
 $onlyIf[$voiceID!=;{description: **You are not connected to a voice channel!**} {color:$getVar[color]}]
 $endif
 
$if[$checkContains[$message;kpop]==true]
 <@$authorID>
 $title[<:music:847284580141498379> Musical Genre]
 $description[Selected **Kpop** Genre, wait while I build your list  $playSpotify[https://open.spotify.com/playlist/37i9dQZF1DX9tPFwDMOaN1?si=d_Hhn_ghSUWqCHZd507DdQ&utm_source=copy-link;name;yes;yes;{color:$getVar[color]}{title:Error}{description:Something went wrong}{delete:5s}{deletecommand}]]
 $color[$getVar[color]]
 $onlyIf[$voiceID!=;{description: **You are not connected to a voice channel!**} {color:$getVar[color]}]
 $endif

$if[$checkContains[$message;lofi]==true]
 <@$authorID>
 $title[<:music:847284580141498379> Musical Genre]
 $description[Selected **Lofi** Genre, wait while I build your list  $playSpotify[https://open.spotify.com/playlist/37i9dQZF1DWWQRwui0ExPn?si=O4P9ZMC_RGyjVoHfq5IUUg&utm_source=copy-link;name;yes;yes;{color:$getVar[color]}{title:Error}{description:Something went wrong}{delete:5s}{deletecommand}]]
 $color[$getVar[color]]
 $onlyIf[$voiceID!=;{description: **You are not connected to a voice channel!**} {color:$getVar[color]}]
 $endif
 
$if[$checkContains[$message;rock]==true]
 <@$authorID>
 $title[<:music:847284580141498379> Musical Genre]
 $description[Selected **Rock** Genre, wait while I build your list  $playSpotify[https://open.spotify.com/playlist/37i9dQZF1DX4908CEYEdlz?si=d0ut6a3WS8esYpVHqL62NQ&utm_source=copy-link;name;yes;yes;{color:$getVar[color]}{title:Error}{description:Something went wrong}{delete:5s}{deletecommand}]]
 $color[$getVar[color]]
 $onlyIf[$voiceID!=;{description: **You are not connected to a voice channel!**} {color:$getVar[color]}]
 $endif

$if[$checkContains[$message;kids]==true]
 <@$authorID>
 $title[<:music:847284580141498379> Musical Genre]
 $description[Selected **Kids** Genre, wait while I build your list  $playSpotify[https://open.spotify.com/playlist/37i9dQZF1DXbnTV8GtwMLQ?si=zL7uCoCRT-SVn75eUWuoBQ&utm_source=copy-link;name;yes;yes;{color:$getVar[color]}{title:Error}{description:Something went wrong}{delete:5s}{deletecommand}]]
 $color[$getVar[color]]
 $onlyIf[$voiceID!=;{description: **You are not connected to a voice channel!**} {color:$getVar[color]}]
 $endif
 
$if[$checkContains[$message;hits]==true]
<@$authorID>
 $title[<:music:847284580141498379> Musical Genre]
 $description[Selected **Hits** Genre, wait while I build your list  $playSpotify[https://open.spotify.com/playlist/37i9dQZEVXbMDoHDwVN2tF?si=grZNfzA1Rg-bVXjJST1PRQ&utm_source=copy-link;name;yes;yes;{color:$getVar[color]}{title:Error}{description:Something went wrong}{delete:5s}{deletecommand}]]
 $color[$getVar[color]]
 $onlyIf[$voiceID!=;{description: **You are not connected to a voice channel!**} {color:$getVar[color]}]
 $endif
 
 $argsCheck[>1;<@$authorID>{title:Musical genres}
 {description:Select the music genre you want so that I can make a list with only the selected genre.

🎵 **Available Genres:**
- \`$getServerVar[prefix]gender\` **pop**
- \`$getServerVar[prefix]gender\` **funk**
- \`$getServerVar[prefix]gender\` **lol**
- \`$getServerVar[prefix]gender\` **sertanejo**
- \`$getServerVar[prefix]gender\` **anime**
- \`$getServerVar[prefix]gender\` **kpop**
- \`$getServerVar[prefix]gender\` **lofi**
- \`$getServerVar[prefix]gender\` **rock**
- \`$getServerVar[prefix]gender\` **kids**
- \`$getServerVar[prefix]gender\` **hits**
 }{color:$getVar[color]}]
 $endif
 
 $channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]

$cooldown[5s;<@$authorID> Você está usando meus comandos muito rápido! $randomText[-_-;OwO;U.u;:<;:0;'_']]
 `
}