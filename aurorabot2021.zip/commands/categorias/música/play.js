module.exports.command = {
 name: "play", aliases: ["p", "tocar"],
 code: `
$if[$getServerVar[lang]==pt-br]

 $eval[
 $title[Música/Playlist Adicionada ao Queue]]
 $if[$checkContains[$message;https://open.spotify.com/playlist]==true]
 $description[<:Spotify:847263256828444672> Playlist | <@$authorID> $playSpotify[$message;name;yes;yes;{color:$getVar[color]}{title:Error}{description:Algo deu errado}{delete:5s}{deletecommand}]]
 $color[$getVar[color]]
 $elseIf[$checkContains[$message;https://open.spotify.com/track/]==true]
 $description[<:Spotify:847263256828444672> Música | <@$authorID> $playSpotify[$message;2m;yes;yes;{color:$getVar[color]}{description:Algo deu errado}{delete:5s}{deletecommand}]]
 $color[$getVar[color]]
 $endelseIf
 $else
 $description[<:youtube:847263278848802818> <@$authorID> $playSong[$message;2m;yes;yes;{color:$getVar[color]}{description:Algo deu errado}{delete:5s}{deletecommand}]]
 $color[$getVar[color]]
 $endif

$onlyIf[$voiceID!=;{description: **Você não está conectado a um canal de voz!**} {color:$getVar[color]}]
 
 $endif
 
 $if[$getServerVar[lang]==en]
 
 $eval[
 $title[Music/Playlist added to Queue]]
 $if[$checkContains[$message;https://open.spotify.com/playlist]==true]
 <@$authorID>
 $description[<:Spotify:847263256828444672> Playlist | <@$authorID> $playSpotify[$message;name;yes;yes;{color:$getVar[color]}{title:Error}{description:Something went wrong}{delete:5s}{deletecommand}]]
 $color[$getVar[color]]
 $elseIf[$checkContains[$message;https://open.spotify.com/track/]==true]
 $description[<:Spotify:847263256828444672> Music | <@$authorID>  $playSpotify[$message;2m;yes;yes;{color:$getVar[color]}{description:Something went wrong}{delete:5s}{deletecommand}]]
 $color[$getVar[color]]
 $endelseIf
 $else
 $description[<:youtube:847263278848802818> <@$authorID>  $playSong[$message;2m;yes;yes;{color:FF0000}{description:Something went wrong}{delete:5s}{deletecommand}]]
 $color[$getVar[color]]
 $endif

$cooldown[5s;<@$authorID> Você está utilizando meus comandos muito rápido! $randomText[-_-;OwO;U.u;:<;:0;'_']]

$onlyIf[$voiceID!=;{description: **You are not connected to a voice channel!**} {color:$getVar[color]}]

$argsCheck[>1;{description:❌ **Use the command correctly**

- **How to use:**
\`$getServerVar[prefix]play <music/link/link playlist>\`
- **Examples:**
\`$getServerVar[prefix]play Kiss me More\`
\`$getServerVar[prefix]play https://open.spotify.com/track/748mdHapucXQri7IAO8yFK?si=aRM5WwZ2TciDb_9d57fadg&utm_source=copy-link\`
- **Synonym**
\`$getServerVar[prefix]p\`
\`$getServerVar[prefix]tocar\`}{color:$getVar[color]}]
 
 $endif
 
 $channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]
  `
}