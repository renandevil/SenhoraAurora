module.exports.command = {
 name: "queue", aliases: ["q", "fila"],
 code:`
 $if[$getServerVar[lang]==pt-br]
 <@$authorID>
 $color[$getVar[color]]
 $author[Queue;$useravatar[$clientID]]
 $title[Músicas em Queue]
 $description[\`($getServerVar[prefix]queue <Página>)\`
 $queue[$replaceText[$replaceText[$checkCondition[$isnumber[$message[1]]==true];true;$replaceText[$replaceText[$checkCondition[$queue[$message[1];10;{title}]!=];false;1];true;$message[1]]];false;1];10;**{number} -** {title} | (<@{userID}>)]]
 $addField[Tocando Agora;[$songinfo[title]]($songinfo[url])(<@$songInfo[userID]>)]

 $footer[Página ($replaceText[$replaceText[$checkCondition[$isnumber[$message[1]]==true];true;$replaceText[$replaceText[$checkCondition[$queue[$message[1];10;{title}]!=];false;1];true;$message[1]]];false;1]/$replaceText[$replaceText[$checkCondition[$getTextSplitLength==1];true;$truncate[$divide[$queueLength;10]]];false;$replaceText[$replaceText[$checkCondition[$splitText[2]==0];true;$truncate[$divide[$queueLength;10]]];false;$sum[$truncate[$divide[$queueLength;10]];1]]]);$authoravatar]

 $textSplit[$divide[$queueLength;10];.]

$onlyIf[$queueLength!=0;{description: Não ah músicas tocando para isto, adicione uma utilizando \`$getServerVar[prefix]play\`}{color:$getVar[color]}]
 
 $onlyIf[$voiceID!=;{color:$getVar[color]}{description: Você não está conectado a um canal de voz!}{delete:10s}]
 
 $onlyIf[$queueLength>0; {color:$getVar[color]}{description:Você não tem música em queue!}]

 $suppressErrors[Algo deu errado]
 
 $endif
 
 $if[$getServerVar[lang]==en]
 <@$authorID>
 $color[$getVar[color]]
 $author[Queue;$useravatar[$clientID]]
 $title[Queue Songs]
 $description[\`($getServerVar[prefix]queue <Page>)\`
 
 $queue[$replaceText[$replaceText[$checkCondition[$isnumber[$message[1]]==true];true;$replaceText[$replaceText[$checkCondition[$queue[$message[1];10;{title}]!=];false;1];true;$message[1]]];false;1];10;**{number} -** {title} | (<@{userID}>)]]
 
 $addField[Playing Now;[$songinfo[title]]($songinfo[url])(<@$songInfo[userID]>)]

 $footer[Page ($replaceText[$replaceText[$checkCondition[$isnumber[$message[1]]==true];true;$replaceText[$replaceText[$checkCondition[$queue[$message[1];10;{title}]!=];false;1];true;$message[1]]];false;1]/$replaceText[$replaceText[$checkCondition[$getTextSplitLength==1];true;$truncate[$divide[$queueLength;10]]];false;$replaceText[$replaceText[$checkCondition[$splitText[2]==0];true;$truncate[$divide[$queueLength;10]]];false;$sum[$truncate[$divide[$queueLength;10]];1]]]);$authoravatar]

 $textSplit[$divide[$queueLength;10];.]

$onlyIf[$queueLength!=0;{description: There are no songs playing for this, add one using \`$getServerVar[prefix]play\`}{color:$getVar[color]}]
 
 $onlyIf[$voiceID!=;{color:$getVar[color]}{description: You are not connected to a voice channel!}]
 
 $onlyIf[$queueLength>0; {color:$getVar[color]}{description: You have no queue music!}]

 $suppressErrors[Something went wrong]
 
 $endif
 
 $channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]
 
$cooldown[5s;<@$authorID> Você está utilizando meus comandos muito rápido! $randomText[-_-;OwO;U.u;:<;:0;'_']]`
}