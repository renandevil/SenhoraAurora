module.exports.command = {
	name: "stop",
	code: `$addCmdReactions[⏹️]
	
	$clearSongQueue
	$textSplit[$stopSong; ]
	
	$cooldown[5s;<@$authorID> **Você precisa esperar %time% para utilizar o comando novamente**{delete:5s} {deletecommand}]

$onlyIf[$queueLength!=0;{description: Não ah músicas tocando para isto, adicione uma utilizando \`$getServerVar[prefix]play\`}{deletecommand}{delete:10s}{color:FEB1D5}]
$onlyif[$voiceid[$authorid]==$voiceid[$clientid];{description: Você não está no mesmo canal de voz que eu!}{color:FEB1D5}{deletecommand}{delete:10s}]
$onlyIf[$voiceID!=;{description: **Você não está conectado a um canal de voz!**}{color: FEB1D5} {deletecommand} {delete:10s}]

 $channelSendMessage[829829140608974888;{title:Logs Comandos}{description: Comando utilizado: \`$getServerVar[prefix]$commandName\`
Servidor: \`$serverName\` ($guildID)
Usuário: \`$userTag\` ($authorID)}]`
}