module.exports.awaitedCommand = {
name: "userinfo",
code: `$editMessage[$message[1];{title:**$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$platform[$replaceText[$findUser[$message;yes];$clientID;817857013698265108]];web;🌐];mobile;📱];desktop;💻];none;❓];, ;]$username[$findUser[$message;yes]]**}{field:**Invites**:
\`$userInfo[real;$findUser[$message]]\`}{field:**Permissões**:
$userPerms[$findUser[$message]]}{field:**Cargos**:
\`$sub[$djsEval[message.guild.members.cache.get('$findMember[$message]').roles.cache.size;yes];1]\`
$replaceText[$replaceText[$checkCondition[$charCount[$userRoles[$findMember[$message];mentions;/]]>1850];true;Tem cargos demais para aparecer nesta tela :0];false;$userRoles[$findMember[$message];mentions; ]]}{thumbnail:$userAvatar[$findUser[$message;yes]]}{color:$replaceText[$getRoleColor[$highestRole[$clientID]];000000;FEB1D5]}]`
}