module.exports.awaitedCommand = {
	name: "50",
	code: `$description[🔉 Volume em 50%] $color[FEB1D5]
	$volume[50]`
}
